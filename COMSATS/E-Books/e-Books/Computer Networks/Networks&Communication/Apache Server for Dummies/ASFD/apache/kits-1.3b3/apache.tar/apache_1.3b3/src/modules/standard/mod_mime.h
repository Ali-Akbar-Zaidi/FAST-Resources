API_EXPORT(int) mime_find_ct(request_rec *r);
