/*
 * OS abstraction functions. Small functions should be defined
 * as "__inline" in os.h.
 */

#include "os.h"

