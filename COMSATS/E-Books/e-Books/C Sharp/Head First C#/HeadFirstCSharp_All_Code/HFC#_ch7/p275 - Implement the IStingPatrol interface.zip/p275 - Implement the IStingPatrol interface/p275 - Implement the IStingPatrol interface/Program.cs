﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p275___Implement_the_IStingPatrol_interface
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
