﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    interface IClown
    {
        string FunnyThingIHave { get; }
        void Honk();
    }
}
