﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p278___TallGuy
{
    interface IClown
    {
        string FunnyThingIHave { get; }
        void Honk();
    }
}
