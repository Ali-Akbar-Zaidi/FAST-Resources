﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Headfirst.Csharp.Leftover2
{
    internal static class LineWriter
    {
        public static void WriteALine(string message)
        {
            Console.WriteLine(message);
        }
    }
}
