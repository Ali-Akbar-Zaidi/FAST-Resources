﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p493___Exception_Magnets
{
    class MyException : Exception { }
}