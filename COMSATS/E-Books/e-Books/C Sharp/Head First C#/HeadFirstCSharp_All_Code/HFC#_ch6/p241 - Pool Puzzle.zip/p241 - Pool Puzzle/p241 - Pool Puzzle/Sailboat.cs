﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pool_Puzzle
{
    class Sailboat : Boat
    {
        public override string move()
        {
            return "  hoist sail   ";
        }
    }
}