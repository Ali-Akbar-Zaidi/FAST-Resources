﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JewelThief
{
    class Jewels
    {
        public string Sparkle()
        {
            return "Sparkle, sparkle!";
        }
    }
}
