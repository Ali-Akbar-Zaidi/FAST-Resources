﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p240___Mixed_Messages
{
    class A
    {
        public int ivar = 7;
        public virtual string m1()
        {
            return "A’s m1, ";
        }
        public string m2()
        {
            return "A’s m2, ";
        }
        public virtual string m3()
        {
            return "A’s m3, ";
        }
    }
}