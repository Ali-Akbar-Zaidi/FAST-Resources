﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p675___Pool_Puzzle
{
    class Program
    {
        static void Main(string[] args)
        {
            new Faucet();
            Console.ReadKey();
        }
    }
}
