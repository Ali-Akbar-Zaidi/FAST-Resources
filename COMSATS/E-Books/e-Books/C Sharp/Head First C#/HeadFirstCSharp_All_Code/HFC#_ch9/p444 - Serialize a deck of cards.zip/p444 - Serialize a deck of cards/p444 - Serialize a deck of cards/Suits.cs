﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p444___Serialize_a_deck_of_cards
{
    enum Suits
    {
        Spades,
        Clubs,
        Diamonds,
        Hearts
    }
}
