﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p710___Starbuzz
{
    enum Drink
    {
        BoringCoffee,
        ChocoRockoLatte,
        TripleEspresso,
        ZestyLemonChai,
        DoubleCappuccino,
        HalfCafAmericano,
        ChocoMacchiato,
        BananaSplitInACup,
    }
}
