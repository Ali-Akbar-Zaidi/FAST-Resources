﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p356___Upcast_an_entire_list
{
    enum KindOfDuck
    {
        Mallard,
        Muscovy,
        Decoy,
    }
}
