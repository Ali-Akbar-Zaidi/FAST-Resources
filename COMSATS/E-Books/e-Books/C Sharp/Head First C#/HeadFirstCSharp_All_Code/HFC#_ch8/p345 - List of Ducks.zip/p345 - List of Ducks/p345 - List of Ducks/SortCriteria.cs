﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p345___List_of_Ducks
{
    enum SortCriteria
    {
        SizeThenKind,
        KindThenSize,
    }

}
