﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p345___List_of_Ducks
{
    enum KindOfDuck
    {
        Mallard,
        Muscovy,
        Decoy,
    }
}
