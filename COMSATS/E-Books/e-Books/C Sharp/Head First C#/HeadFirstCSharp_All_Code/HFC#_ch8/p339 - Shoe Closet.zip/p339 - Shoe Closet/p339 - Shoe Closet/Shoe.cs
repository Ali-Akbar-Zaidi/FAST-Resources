﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p339___Shoe_Closet
{
    class Shoe
    {
        public Style Style;
        public string Color;
    }
}
