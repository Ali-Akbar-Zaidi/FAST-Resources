﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p339___Shoe_Closet
{
    enum Style
    {
        Sneakers,
        Loafers,
        Sandals,
        Flipflops,
        Wingtips,
        Clogs,
    }
}
