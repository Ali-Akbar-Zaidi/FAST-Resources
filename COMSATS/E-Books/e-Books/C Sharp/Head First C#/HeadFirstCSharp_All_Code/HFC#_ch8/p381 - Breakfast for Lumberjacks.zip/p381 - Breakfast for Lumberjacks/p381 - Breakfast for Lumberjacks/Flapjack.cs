﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p381___Breakfast_for_Lumberjacks
{
    enum Flapjack
    {
        Crispy,
        Soggy,
        Browned,
        Banana
    }
}
