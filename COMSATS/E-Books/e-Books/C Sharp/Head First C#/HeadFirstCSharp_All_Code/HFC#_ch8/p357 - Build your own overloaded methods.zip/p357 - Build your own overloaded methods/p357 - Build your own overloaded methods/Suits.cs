﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p357___Build_your_own_overloaded_methods
{
    enum Suits
    {
        Spades,
        Clubs,
        Diamonds,
        Hearts
    }
}
