﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p358___Two_Decks
{
    enum Suits
    {
        Spades,
        Clubs,
        Diamonds,
        Hearts
    }
}
