import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/index'; //1
import Home from './components/HomePage'; //2
import ForgotCredentials from './components/ForgotCredentials'; //3
import PredictETH from './components/PredictETH'; //4
import PredictBTC from './components/PredictBTC'; //5
import Profile from './components/Profile'; //6
import Trade from './components/Trade'; //7

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="forgotCredentials" element={<ForgotCredentials />} />
        <Route path="predictETH" element={<PredictETH />} />
        <Route path="predictBTC" element={<PredictBTC />} />
        <Route path="profile" element={<Profile />} />
        <Route path="trade" element={<Trade />} />
      </Routes>
    </Router>
  );
}

export default App;
