import React, { useState } from 'react';
import './index.css';

function LoginPage() {
    const [login, setLogin] = useState({
        username: "",
        password: "",
    });

    const handleLogin = (e) => {
        console.log(e);
        let name = e.target.name;
        let value = e.target.value;

        setLogin({
            ...login,
            [name]: value,
        })
    }

    const handleLoginSubmit = async (e) => {
        e.preventDefault();
        console.log(login);
        try {
            const response = await fetch(`http://localhost:5000/api/auth/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(login),
            });
            if (response.status === 200) {
                const res_data = await response.json();

                localStorage.setItem('token', res_data.token);
                localStorage.setItem('userId', res_data.userId);
                localStorage.setItem('user', res_data.user);
                localStorage.setItem('email', res_data.email);
                localStorage.setItem('password', res_data.password);
                localStorage.setItem('btc', res_data.btc);
                localStorage.setItem('eth', res_data.eth);

                alert("Login Successful!.")
                window.location.href = "/";
            } else {
                alert("Incorrect Credentials!")
            }
        } catch (error) {
            console.log("login", error);
        }
    }

    const [signUp, setSignUp] = useState({
        username: "",
        email: "",
        password: "",
    });

    const handleSignUp = (e) => {
        console.log(e);
        let name = e.target.name;
        let value = e.target.value;

        setSignUp({
            ...signUp,
            [name]: value,
        })
    }

    const handleSignUpSubmit = async (e) => {
        e.preventDefault();
        console.log(signUp);
        try {
            const response = await fetch(`http://localhost:5000/api/auth/signUp`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(signUp),
            });
            if (response.status !== 300) {
                alert("SignUp Successful! Now login with the account you have registered.")
                window.location.href = "login";
            } else if (response.status === 300) {
                alert("This Username or Email already exists!")
            }
        } catch (error) {
            console.log("SignUp", error);
        }
    }

    const handleForgotCredentials = async (e) => {
        e.preventDefault();
        try {
            window.location.href = "forgotCredentials";
        } catch (error) {
            console.log(error);
        }
    }

    return (
        <div className='body1'>
            <div className="main1">
                <input type="checkbox" id="check1" aria-hidden="true" />
                <div className="login1">
                    <form onSubmit={handleLoginSubmit}>
                        <label className='label1' htmlFor="check1" aria-hidden="true">Login</label>
                        <input
                            className='input1'
                            type="text"
                            name="username"
                            placeholder="Username"
                            value={login.username}
                            onChange={handleLogin}
                            required
                        />
                        <input
                            className='input1'
                            type="password"
                            name="password"
                            placeholder="Password"
                            value={login.password}
                            onChange={handleLogin}
                            required
                        />
                        <button className='button1'>Login</button>
                    </form>
                    <form onSubmit={handleForgotCredentials}><button className='button1'>Forgot Credentials?</button></form>
                </div>
                <div className="signUp1">
                    <form onSubmit={handleSignUpSubmit}>
                        <label className='label1' htmlFor="check1" aria-hidden="true">Sign Up</label>
                        <input
                            className='input1'
                            type="text"
                            name="username"
                            placeholder="Username"
                            value={signUp.username}
                            onChange={handleSignUp}
                            required
                        />
                        <input
                            className='input1'
                            type="email"
                            name="email"
                            placeholder="Email"
                            value={signUp.email}
                            onChange={handleSignUp}
                            required
                        />
                        <input
                            className='input1'
                            type="password"
                            name="password"
                            placeholder="Password"
                            value={signUp.password}
                            onChange={handleSignUp}
                            required
                        />
                        <button className='button1'>Sign Up</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default LoginPage;