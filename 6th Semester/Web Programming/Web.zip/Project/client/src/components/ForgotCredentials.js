import React, { useState } from 'react';
import './ForgotCredentials.css';

function ForgotCredentials() {
    const [credentials, setCredentials] = useState({
        username: "", email: "",
    });

    const handleCredentials = (e) => {
        console.log(e);
        let name = e.target.name;
        let value = e.target.value;

        setCredentials({
            ...credentials, [name]: value,
        })
    }

    const sendEmail = async (e) => {
        e.preventDefault();
        console.log("Sending email with credentials:", credentials);
        try {
            const response = await fetch(`http://localhost:5000/api/auth/forgotCredentials`, {
                method: "POST", headers: { "Content-Type": "application/json", }, body: JSON.stringify(credentials),
            });
            if (response.status === 200) {
                alert("Password Sent to your Email!");
                window.location.href = "login";
            } else if (response.status === 300) {
                alert("Invalid Credentials!");
            } else {
                alert("Failed to send Email!");
            }
        } catch (error) {
            console.error("Email send error:", error);
            alert("An error occurred while sending the email.");
        }
    };

    return (
        <div className='body3'>
            <div className="resetPass">
                <form onSubmit={sendEmail}>
                    <label htmlFor="check" aria-hidden="true">Reset Password</label>
                    <input
                        type="text" name="username" placeholder="Username"
                        value={credentials.username} onChange={handleCredentials} required
                    />
                    <input
                        type="email" name="email" placeholder="Email"
                        value={credentials.email} onChange={handleCredentials} required
                    />
                    <button type="submit">Submit</button>
                </form>
                <p>(Note: Your password will be sent to the above entered email after you submit.)</p>
            </div>
        </div>
    );
}

export default ForgotCredentials;
