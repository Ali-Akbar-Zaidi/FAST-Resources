import React, { useState } from 'react';
import './Profile.css';

function Profile() {

    const [profile, setProfile] = useState({
        userId: localStorage.getItem("userId"),
        username: localStorage.getItem("user"),
        email: localStorage.getItem("email"),
        password: localStorage.getItem("password"),
    });

    const setProfileData = (e) => {
        console.log(e);
        let name = e.target.name;
        let value = e.target.value;

        setProfile({
            ...profile,
            [name]: value,
        })
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(profile);
        try {
            const response = await fetch(`http://localhost:5000/api/auth/updateProfile`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(profile),
            });
            if (response.status === 200) {
                const res_data = await response.json();
                localStorage.setItem("user", res_data.username);
                localStorage.setItem("email", res_data.email);
                localStorage.setItem("password", res_data.password);
                alert('Profile updated successfully');
            } else {
                alert('Failed to update profile');
            }
        } catch (error) {
            console.log("login", error);
        }
    }

    const returnBtcWorth = () => {
        return (parseFloat(localStorage.getItem('btc')) * 61731.50);
    }

    const returnEthWorth = () => {
        return (parseFloat(localStorage.getItem('eth')) * 2905.31);
    }

    return (
        <div className='body6'>
            <section className="container">
                <div className="credentials">
                    <form onSubmit={handleSubmit}>
                        <label className="header" htmlFor="check" aria-hidden="true">My Profile</label>

                        <label htmlFor="" className="crLabel">Username</label>
                        <input
                            type="text"
                            name="username"
                            placeholder="Username"
                            value={profile.username}
                            onChange={setProfileData}
                            required
                        />

                        <label htmlFor="" className="crLabel">Email</label>
                        <input
                            type="email"
                            name="email"
                            placeholder="Email"
                            value={profile.email}
                            onChange={setProfileData}
                            required
                        />

                        <label htmlFor="" className="crLabel">Password</label>
                        <input
                            type="text"
                            name="password"
                            placeholder="Password"
                            value={profile.password}
                            onChange={setProfileData}
                            required
                        />

                        <button type="submit">Update</button>
                    </form>
                    <br /><br />
                    <p>(Note: The details will be updated once you click the Update button.)</p>
                </div>
                <div className="otherDetails">
                    <label className="header" htmlFor="check" aria-hidden="true">My Assets</label>
                    <section className='assetsSection'>
                        <div className='btcSection'>
                            <label className='assetsLabel'>BTC</label>
                            <p className='assetsP'>Quantity: {localStorage.getItem('btc')}</p>
                            <p className='assetsP'>Worth: $ {returnBtcWorth()}</p>
                        </div>
                        <div className='ethSection'>
                            <label className='assetsLabel'>ETH</label>
                            <p className='assetsP'>Quantity: {localStorage.getItem('eth')}</p>
                            <p className='assetsP'>Worth: $ {returnEthWorth()}</p>
                        </div>
                    </section>
                </div>
            </section>
        </div>
    );
}

export default Profile;
