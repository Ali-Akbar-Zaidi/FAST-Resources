import React from 'react';
import './App.css';
import Mailbox from './Mailbox.js';
import Football from './Football.js';
import Greeting from './Greeting.js';
import Clock from './Clock.js';
import ScrollToTopButton from './ScrollToTopButton.js';
import UserForm from './UserForm.js';

let messages = ['React', 'Re: React', 'Re:Re: React'];

function App() {
  return (
    <div className='mainDiv'>
      <div><br></br></div>
      <div className='breakingLine'></div>
      <header className='header'>Task-1</header>
      <Mailbox unreadMessages={messages} />
      
      <div className='breakingLine'></div>
      <header className='header'>Task-3</header>
      <Football />
      <div><br></br></div>

      <div className='breakingLine'></div>
      <header className='header'>Task-4</header>
      <Greeting />

      <div className='breakingLine'></div>
      <header className='header'>Task-5</header>
      <Clock />

      <div className='breakingLine'></div>
      <header className='header'>Task-6</header>
      <ScrollToTopButton />
      <div><br></br></div>

      <div className='breakingLine'></div>
      <header className='header'>Task-7</header>
      <UserForm />
      <div><br></br></div>
      <div className='breakingLine'></div>
      <div><br></br></div>
    </div>
  );
}

export default App;
