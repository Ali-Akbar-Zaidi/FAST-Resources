import React from 'react';

class Mailbox extends React.Component {
  render() {
    const x = this.props.unreadMessages;
    const unreadCount = x.length;

    return (
      <div>
        <h2>Hello!</h2>
        {unreadCount > 0 && ( <p>You have {unreadCount} unread messages.</p> )}
      </div>
    );
  }
}

export default Mailbox;
