import React from 'react';

function ScrollToTopButton() {
    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    return (
        <button onClick={scrollToTop}>
            Scroll To Top
        </button>
    );
}

export default ScrollToTopButton;
