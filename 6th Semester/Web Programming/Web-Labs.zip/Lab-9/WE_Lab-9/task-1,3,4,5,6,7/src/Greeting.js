import React, { useState } from 'react';

function Greeting({ name }) {
    const [userName, setUserName] = useState(name);

    const handleInputChange = (event) => {
        setUserName(event.target.value);
    };

    return (
        <div>
            <label htmlFor="nameInput">Enter your name : </label>
            <input
                type="text"
                id="nameInput"
                value={userName}
                onChange={handleInputChange}
            />
            <p>Hello, {userName}!</p>
        </div>
    );
}

export default Greeting;
