import React from 'react';

function Football() {
    const shoot = (message) => {
        alert(message);
    };

    return (
        <button onClick={() => shoot("Goal!")}>
            Shoot
        </button>
    );
}

export default Football;
