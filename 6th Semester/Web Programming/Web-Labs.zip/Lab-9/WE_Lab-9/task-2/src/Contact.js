import React from 'react';

function Contact() {
    return <h1 className='heading'>Contact Page</h1>;
}

export default Contact;
