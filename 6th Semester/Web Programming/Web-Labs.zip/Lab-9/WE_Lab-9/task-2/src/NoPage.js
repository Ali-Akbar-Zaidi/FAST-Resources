import React from 'react';

function NoPage() {
    return <h1 className='heading'>404 - Page Not Found</h1>;
}

export default NoPage;
