import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
    // return <h1 className='heading'>Home Page</h1>;
    return (
        <div className='mainDiv'>
            <nav className='navBar'>
                <ul className='navItems'>
                    <li className='item'><Link to="/">Home</Link></li>
                    <li className='item'><Link to="blogs" target='_blank'>Blogs</Link></li>
                    <li className='item'><Link to="contact">Contact</Link></li>
                </ul>
            </nav>
            {/* <Outlet /> */}
        </div>
    );
}

export default Home;
