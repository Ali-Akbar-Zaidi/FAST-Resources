import React from 'react';
import { Link, Outlet } from 'react-router-dom';

function Layout() {
    return (
        <div className='mainDiv'>
            <nav className='navBar'>
                <ul className='navItems'>
                    <li className='item'><Link to="/">Home</Link></li>
                    <li className='item'><Link to="blogs">Blogs</Link></li>
                    <li className='item'><Link to="contact">Contact</Link></li>
                </ul>
            </nav>
            <Outlet />
        </div>
    );
}

export default Layout;
