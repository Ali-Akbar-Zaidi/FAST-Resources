import React from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Layout from './Layout';
import Home from './Home';
import Blogs from './Blogs';
import Contact from './Contact';
import NoPage from './NoPage';

function App() {
  return (
    <Router>
      <Routes>
        {/* <Route path="/" element={<Layout />}> */}
          {/* <Route path="/" element={<Home />} /> */}
          <Route path="/" element={<Blogs />} />
          <Route path="contact" element={<Contact />} />
          <Route path="*" element={<NoPage />} />
        {/* </Route> */}
      </Routes>
    </Router>
  );
}

export default App;
