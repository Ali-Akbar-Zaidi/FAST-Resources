import React, { useState } from 'react';

function Counter() {
    const [counter, setCounter] = useState(0);

    const incrementCounter = () => {
        setCounter(prevCounter => prevCounter + 1);
    };

    const decrementCounter = () => {
        setCounter(prevCounter => prevCounter - 1);
    };

    return (
        <div>
            <header className="header">
                <h2 className="heading">Press the below buttons to perform the respective operations:-</h2>
            </header>
            <section className="section">
                <button className="plus" onClick={incrementCounter}>+</button>
                <label>{counter}</label>
                <button className="minus" onClick={decrementCounter}>-</button>
            </section>
        </div>
    );
}

export default Counter;
