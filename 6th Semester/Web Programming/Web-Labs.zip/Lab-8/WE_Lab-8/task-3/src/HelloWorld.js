import React, { Component } from 'react';

class HelloWorld extends Component {
    render() {
        return (
            <div>
                <h1 className='helloWorld'>Hello World!</h1>
            </div>
        );
    }
}

export default HelloWorld;
