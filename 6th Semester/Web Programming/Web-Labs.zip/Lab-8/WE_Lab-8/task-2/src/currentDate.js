import React from 'react';

class currentDate extends React.Component {
    render() {
        const currentDate = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = new Intl.DateTimeFormat('en-US', options).format(currentDate);

        return (
            <div>
                <h3>Current Date: {formattedDate}</h3>
            </div>
        );
    }
}

export default currentDate;
