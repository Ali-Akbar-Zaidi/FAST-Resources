import './App.css';
import Name from './Name';
import Tareekh from './currentDate';
import Time from './Time';

function App() {
  return (
    <div className="App">
      <Name />
      <Tareekh />
      <Time />
    </div>
  );
}

export default App;
