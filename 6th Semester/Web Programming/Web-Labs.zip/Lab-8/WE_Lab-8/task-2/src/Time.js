import React from 'react';

class Time extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentTime: new Date().toLocaleTimeString()
        };
    }

    componentDidMount() {
        this.intervalID = setInterval(
            () => this.tick(),
            1000
        );
    }

    componentWillUnmount() {
        clearInterval(this.intervalID);
    }

    tick() {
        this.setState({
            currentTime: new Date().toLocaleTimeString()
        });
    }

    render() {
        return (
            <div>
                <h3>Current Time: {this.state.currentTime}</h3>
            </div>
        );
    }
}

export default Time;
