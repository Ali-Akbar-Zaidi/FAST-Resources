import React from 'react';

class Name extends React.Component {
    render() {
        return (
            <div>
                <p className='nameParagraph'>My Name is Abubakar Shahid</p>
            </div>
        );
    }
}

export default Name;
