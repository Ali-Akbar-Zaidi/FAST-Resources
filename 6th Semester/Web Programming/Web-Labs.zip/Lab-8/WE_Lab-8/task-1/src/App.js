import './App.css';

function App() {
  return (
    <div className = "App">
      <header className = "header">
        <h1>Welcome to My First React Application!!!</h1>
      </header>
      <section className = "section">
        <p className = "paragraph">Following is the list of some Top Netflix Series:-</p>
        <ol className = "list">
          <li>Files of the Unexplained</li>
          <li>3 Body Problem</li>
          <li>Parasyte: The Grey</li>
          <li>Bad Dinosaurs</li>
          <li>Ripley</li>
          <li>The Gentlemen</li>
          <li>Baby Reindeer</li>
          <li>The Magic Prank Show with Justin Willman</li>
          <li>Top Boy</li>
          <li>Stranger Things</li>
        </ol>
      </section>
    </div>
  );
}

export default App;
