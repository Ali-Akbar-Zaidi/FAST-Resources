import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;
import org.junit.runner.Description;

public class TestRunner {
    public static void main(String[] args) throws Exception {
        Class<?>[] tests = new Class<?>[] {
                AndGateTest.class,
                OrGateTest.class,
                NotGateTest.class,
                PortTest.class,
                ConnectorTest.class,
                CircuitSimulatorTest.class
        };

        JUnitCore core = new JUnitCore();
        core.addListener(new RunListener() {
            @Override
            public void testStarted(Description description) throws Exception {
                System.out.println("STARTED: " + description.getClassName() + "#" + description.getMethodName());
            }

            @Override
            public void testFinished(Description description) throws Exception {
                System.out.println("PASSED:  " + description.getClassName() + "#" + description.getMethodName());
                System.out.println();
            }

            @Override
            public void testFailure(Failure failure) throws Exception {
                Description d = failure.getDescription();
                System.out.println("FAILED:  " + d.getClassName() + "#" + d.getMethodName());
                System.out.println("Exception: " + failure.getException());
                String msg = failure.getMessage();
                if (msg != null) {
                    System.out.println("Message: " + msg);
                    // Try to extract expected/actual if present
                    if (msg.contains("expected") && msg.contains("but was")) {
                        System.out.println("Details: " + msg);
                    }
                }
                System.out.println();
            }

            @Override
            public void testIgnored(Description description) throws Exception {
                System.out.println("IGNORED: " + description.getClassName() + "#" + description.getMethodName());
                System.out.println();
            }
        });

        Result result = core.run(tests);
        System.out.println("SUMMARY: run=" + result.getRunCount() + " failed=" + result.getFailureCount() + " ignored="
                + result.getIgnoreCount() + " time=" + result.getRunTime() + "ms");
        if (!result.getFailures().isEmpty()) {
            System.out.println("Failure details:");
            for (Failure f : result.getFailures()) {
                System.out.println("- " + f.getDescription().getClassName() + "#" + f.getDescription().getMethodName());
                System.out.println("  " + f.getMessage());
            }
        }
    }
}
