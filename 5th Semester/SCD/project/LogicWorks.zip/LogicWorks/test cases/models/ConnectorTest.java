import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import models.Connector;
import models.AndGate;
import models.OrGate;
import models.Port;

public class ConnectorTest {
    private Connector conn;
    private AndGate src;
    private OrGate dst;

    @Before
    public void setup() {
        src = new AndGate("AND1", 0, 0);
        dst = new OrGate("OR1", 100, 0);
        Port pSrc = src.getOutputPort();
        Port pDst = dst.getInputPorts().get(0);
        conn = new Connector("c1", src, dst, pSrc, pDst);
    }

    @Test
    public void initialValue_shouldBeFalse() {
        assertFalse(conn.getValue());
    }

    @Test
    public void process_shouldPropagateSourceOutput() {
        src.setInput(true, true);
        src.execute();
        conn.process();
        assertTrue(conn.getValue());
    }
}
