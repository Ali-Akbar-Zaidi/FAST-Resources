import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import models.NotGate;

public class NotGateTest {
    private NotGate gate;

    @Before
    public void setup() {
        gate = new NotGate("NOT1", 0, 0);
    }

    @Test
    public void inputTrue_shouldBeFalse() {
        gate.setInput(true);
        gate.execute();
        assertFalse(gate.getOutput());
    }

    @Test
    public void inputFalse_shouldBeTrue() {
        gate.setInput(false);
        gate.execute();
        assertTrue(gate.getOutput());
    }

    @Test(expected = IllegalArgumentException.class)
    public void multipleInputs_shouldThrow() {
        gate.setInput(true, false);
    }
}
