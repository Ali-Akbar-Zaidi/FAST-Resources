import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import models.Port;
import models.AndGate;

public class PortTest {
    private Port pIn;
    private Port pOut;
    private AndGate gate;

    @Before
    public void setup() {
        gate = new AndGate("AND1", 100, 100);
        pIn = new Port("IN1", Port.PortType.INPUT, gate, 0);
        pOut = new Port("OUT", Port.PortType.OUTPUT, gate, 0);
    }

    @Test
    public void initialValue_shouldBeFalse() {
        assertFalse(pIn.getValue());
    }

    @Test
    public void setValue_shouldUpdate() {
        pIn.setValue(true);
        assertTrue(pIn.getValue());
    }

    @Test
    public void absolutePositions_shouldBeComputed() {
        int x = pIn.getAbsoluteX();
        int y = pIn.getAbsoluteY();
        assertEquals(100 - 10, x);
        assertEquals(100 + 10, y);

        int ox = pOut.getAbsoluteX();
        int oy = pOut.getAbsoluteY();
        assertEquals(100 + 60 + 5, ox);
    }
}
