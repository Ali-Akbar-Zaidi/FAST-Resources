import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import models.OrGate;

public class OrGateTest {
    private OrGate gate;

    @Before
    public void setup() {
        gate = new OrGate("OR1", 0, 0);
    }

    @Test
    public void bothFalse_shouldBeFalse() {
        gate.setInput(false, false);
        gate.execute();
        assertFalse(gate.getOutput());
    }

    @Test
    public void oneTrue_shouldBeTrue() {
        gate.setInput(true, false);
        gate.execute();
        assertTrue(gate.getOutput());
    }

    @Test
    public void bothTrue_shouldBeTrue() {
        gate.setInput(true, true);
        gate.execute();
        assertTrue(gate.getOutput());
    }
}
