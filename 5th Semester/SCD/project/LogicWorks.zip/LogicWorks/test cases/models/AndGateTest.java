import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import models.AndGate;

public class AndGateTest {
    private AndGate gate;

    @Before
    public void setup() {
        gate = new AndGate("AND1", 0, 0);
    }

    @Test
    public void bothFalse_shouldBeFalse() {
        gate.setInput(false, false);
        gate.execute();
        assertFalse(gate.getOutput());
    }

    @Test
    public void bothTrue_shouldBeTrue() {
        gate.setInput(true, true);
        gate.execute();
        assertTrue(gate.getOutput());
    }

    @Test
    public void oneFalse_oneTrue_shouldBeFalse() {
        gate.setInput(true, false);
        gate.execute();
        assertFalse(gate.getOutput());
    }
}
