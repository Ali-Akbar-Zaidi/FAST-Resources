import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import models.AndGate;
import models.InputSwitch;
import models.Component;
import services.CircuitSimulator;
import services.ConnectionManager;

public class CircuitSimulatorTest {
    private List<Component> components;
    private ConnectionManager connMgr;
    private CircuitSimulator sim;

    @Before
    public void setup() {
        components = new ArrayList<>();
        connMgr = new ConnectionManager();
        sim = new CircuitSimulator(components, connMgr);
    }

    @Test
    public void singleAndGate_shouldExecute() {
        AndGate a = new AndGate("AND1", 0, 0);
        components.add(a);
        a.setInput(true, true);
        sim.simulate();
        assertTrue(a.getOutput());
    }

    @Test
    public void inputSwitch_shouldPropagateState() {
        InputSwitch sw = new InputSwitch("SW1", 0, 0);
        components.add(sw);
        sw.setSwitchState(true);
        sim.simulate();
        assertTrue(sw.getOutput());
    }
}
