package ui;

import javax.swing.*;
import models.Projects;
import controllers.CircuitController;
import java.awt.BorderLayout;
import java.io.IOException;

public class ProjectWindow extends JFrame {
    private Projects project;
    private JLabel label;
    private JButton saveButton;
    private JButton newCircuitButton;
    private JButton openCircuitButton;
    private DefaultListModel<models.Circuits> listModel;
    private JList<models.Circuits> circuitList;
    private CircuitController controller;
    private JButton deleteButton;

    public ProjectWindow(Projects project) {
        this.project = project;
        this.controller = new CircuitController();
        setTitle("Project - " + project.getProjectName());
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        label = new JLabel("Project: " + project.getProjectName() + " at " + project.getProjectPath());

        // Top panel with label and New Circuit button
        JPanel top = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        newCircuitButton = new JButton("New Circuit");
        top.add(label);
        top.add(newCircuitButton);

        // Center area: list of circuits inside a scroll pane
        listModel = new DefaultListModel<>();
        circuitList = new JList<>(listModel);
        circuitList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(circuitList);

        // Load existing circuits from project model
        for (models.Circuits c : project.getCircuits()) {
            listModel.addElement(c);
        }

        // Bottom panel with Save button
        JPanel bottom = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
        saveButton = new JButton("Save");
        openCircuitButton = new JButton("Open Circuit");
        deleteButton = new JButton("Delete Circuit");
        bottom.add(deleteButton);
        bottom.add(saveButton);
        bottom.add(openCircuitButton);

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        // Actions
        newCircuitButton.addActionListener(e -> onNewCircuit());
        saveButton.addActionListener(e -> onSave());
        openCircuitButton.addActionListener(e -> onOpenCircuit());
        deleteButton.addActionListener(e -> onDeleteCircuit());
        setLocationRelativeTo(null);
    }

    private void onNewCircuit() {
        String name = JOptionPane.showInputDialog(this, "Enter circuit name:", "New Circuit",
                JOptionPane.PLAIN_MESSAGE);
        if (name == null)
            return; // cancelled
        name = name.trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Circuit name cannot be empty.", "Invalid",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Use controller to create circuit and update UI
        models.Circuits c = controller.createCircuit(project, name);
        if (c != null) {
            listModel.addElement(c);
        }
    }

    private void onSave() {
        try {
            controller.saveProject(project);
            JOptionPane.showMessageDialog(this, "Project saved.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save project: " + ex.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onOpenCircuit() {
        models.Circuits selected = circuitList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a circuit to open.", "No selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String content = controller.openCircuit(project, selected);
            ui.CircuitWindow cw = new ui.CircuitWindow(project, selected, content, controller);
            cw.setVisible(true);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to open circuit: " + ex.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onDeleteCircuit() {
        models.Circuits selected = circuitList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a circuit to delete.", "No selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete the circuit: " + selected.getCircuitName() + "?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION)
            return;

        try {
            controller.deleteCircuit(project, selected);
            listModel.removeElement(selected);
            JOptionPane.showMessageDialog(this, "Circuit deleted.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to delete circuit: " + ex.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
