package ui;

import javax.swing.*;
import models.Projects;
import models.Circuits;
import controllers.CircuitController;
import controllers.CircuitImportController;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;
import utils.CircuitCanvas;

public class CircuitWindow extends JFrame {
    private Projects project;
    private Circuits circuit;
    private CircuitController controller;
    private CircuitCanvas canvas;
    private CircuitImportController importController;
    
    private JButton saveButton;
    private JButton closeButton;
    private JButton exportButton;
    private JButton importButton;
    private JButton AndGateButton;
    private JButton OrGateButton;
    private JButton NotGateButton;
    private JButton InputButton;
    private JButton OutputButton;
    private JButton removeGate;
    private JButton simulateButton;
    private JButton resetButton;
    private JButton clearButton;
    private JButton connectButton;
    private JButton analyzeButton;

    public CircuitWindow(Projects project, Circuits circuit, String initialContent, CircuitController controller) {
        this.project = project;
        this.circuit = circuit;
        this.controller = controller;

        setTitle("Circuit Designer - " + circuit.getCircuitName());
        setSize(1000, 700);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Top panel
        JLabel top = new JLabel("Circuit: " + circuit.getCircuitName());
        top.setHorizontalAlignment(SwingConstants.CENTER);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        top.setFont(top.getFont().deriveFont(16f));
        add(top, BorderLayout.NORTH);

        // Left panel - Component buttons
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        leftPanel.setBackground(new Color(240, 240, 240));
        
        // Input/Output section
        JLabel ioLabel = new JLabel("Input/Output:");
        ioLabel.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        ioLabel.setFont(ioLabel.getFont().deriveFont(14f));
        leftPanel.add(ioLabel);
        leftPanel.add(Box.createVerticalStrut(10));
        
        InputButton = new JButton("Input Switch");
        OutputButton = new JButton("Output Light");
        InputButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        OutputButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        InputButton.setBackground(new Color(150, 255, 150));
        OutputButton.setBackground(new Color(255, 255, 150));
        
        leftPanel.add(InputButton);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(OutputButton);
        leftPanel.add(Box.createVerticalStrut(20));
        

        // Logic gates section
        JLabel gatesLabel = new JLabel("Logic Gates:");
        gatesLabel.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        gatesLabel.setFont(gatesLabel.getFont().deriveFont(14f));
        leftPanel.add(gatesLabel);
        leftPanel.add(Box.createVerticalStrut(10));
        
        AndGateButton = new JButton("AND Gate");
        OrGateButton = new JButton("OR Gate");
        NotGateButton = new JButton("NOT Gate");
        
        AndGateButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        OrGateButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        NotGateButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        
        leftPanel.add(AndGateButton);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(OrGateButton);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(NotGateButton);
        leftPanel.add(Box.createVerticalStrut(20));
        
        // Instructions
        JLabel instructionsLabel = new JLabel("<html><div style='text-align: center;'>" +
                "<b>How to Use:</b><br><br>" +
                "1. Add components from buttons<br>" +
                "2. <b>Select a component</b><br>" +
                "3. <b>Click 'Connect'</b> button<br>" +
                "4. <b>Enter target component name</b><br>" +
                "5. Click Input Switch to toggle<br>" +
                "6. Click Simulate to run<br>" +
                "7. Use Import to merge circuits<br><br>" +
                "<i>Drag components to move</i>" +
                "</div></html>");
        instructionsLabel.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        leftPanel.add(instructionsLabel);
        
        add(leftPanel, BorderLayout.WEST);

        // Center - Canvas
        canvas = new CircuitCanvas(20, 30, 30);
        
        // Initialize import controller
        importController = new CircuitImportController(canvas, canvas.getController().getConnectionManager());
        
        // If initial content provided (when opening existing circuit), load it into canvas
        if (initialContent != null && !initialContent.trim().isEmpty()) {
            canvas.loadFromSerializedString(initialContent);
        }
        JScrollPane scrollPane = new JScrollPane(canvas);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom panel - Control buttons
        JPanel bottom = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 10));
        
        connectButton = new JButton("🔗 Connect");
        simulateButton = new JButton("▶ Simulate");
        analyzeButton = new JButton("Analyze (Truth Table)");
        resetButton = new JButton("↻ Reset");
        removeGate = new JButton("Remove Selected");
        clearButton = new JButton("Clear All");
        importButton = new JButton("📥 Import Circuit");
        saveButton = new JButton("💾 Save");
        exportButton = new JButton("Export PNG/JPEG");
        closeButton = new JButton("Close");
        
        connectButton.setBackground(new Color(150, 255, 200));
        simulateButton.setBackground(new Color(150, 200, 255));
        resetButton.setBackground(new Color(255, 200, 150));
        clearButton.setBackground(new Color(255, 150, 150));
        importButton.setBackground(new Color(200, 150, 255));
        
        connectButton.setToolTipText("Connect selected component to another component");
        simulateButton.setToolTipText("Run circuit simulation");
        analyzeButton.setToolTipText("Generate truth table and boolean expressions");
        resetButton.setToolTipText("Reset all components and inputs");
        removeGate.setToolTipText("Remove selected component");
        clearButton.setToolTipText("Clear entire canvas");
        importButton.setToolTipText("Import another circuit into this one (excludes INPUT/OUTPUT)");
        
        bottom.add(connectButton);
        bottom.add(analyzeButton);
        bottom.add(new JSeparator(SwingConstants.VERTICAL));
        bottom.add(simulateButton);
        bottom.add(resetButton);
        bottom.add(new JSeparator(SwingConstants.VERTICAL));
        bottom.add(removeGate);
        bottom.add(clearButton);
        bottom.add(new JSeparator(SwingConstants.VERTICAL));
        bottom.add(importButton);
        bottom.add(exportButton);
        bottom.add(new JSeparator(SwingConstants.VERTICAL));
        bottom.add(saveButton);
        bottom.add(closeButton);
        
        add(bottom, BorderLayout.SOUTH);

        // Event listeners for Buttons Features
        saveButton.addActionListener(e -> onSave());
        closeButton.addActionListener(e -> dispose());
        AndGateButton.addActionListener(e -> canvas.getController().addGate("AND"));
        OrGateButton.addActionListener(e -> canvas.getController().addGate("OR"));
        NotGateButton.addActionListener(e -> canvas.getController().addGate("NOT"));
        InputButton.addActionListener(e -> canvas.getController().addGate("INPUT"));
        OutputButton.addActionListener(e -> canvas.getController().addGate("OUTPUT"));
        removeGate.addActionListener(e -> canvas.getController().removeSelectedGate());
        clearButton.addActionListener(e -> onClear());
        importButton.addActionListener(e -> onImport());
        exportButton.addActionListener(e -> onExport());
        analyzeButton.addActionListener(e -> onAnalyze());
        simulateButton.addActionListener(e -> canvas.getController().simulate());
        resetButton.addActionListener(e -> canvas.getController().resetSimulation());
        connectButton.addActionListener(e -> canvas.getController().connectSelectedToComponent());

        setLocationRelativeTo(null);
    }

    private void onSave() {
        try {
            controller.saveCircuit(project, circuit, canvas.serializeToString());
            JOptionPane.showMessageDialog(this, "Circuit saved successfully!", "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to save circuit: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onClear() {
        int result = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to clear the entire canvas?", 
                "Confirm Clear", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.WARNING_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            canvas.getController().clearCanvas();
        }
    }

    private void onImport() {
        // Show dialog to select a circuit file to import
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select Circuit to Import");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Circuit Files (*.circ)", "circ");
        chooser.setFileFilter(filter);
        
        // Start from project circuits directory if available
        if (project != null) {
            try {
                java.nio.file.Path circuitsDir = java.nio.file.Paths.get(
                    project.getProjectPath(), 
                    project.getProjectName(), 
                    "circuits"
                );
                if (Files.exists(circuitsDir)) {
                    chooser.setCurrentDirectory(circuitsDir.toFile());
                }
            } catch (Exception ex) {
                // Ignore and use default directory
            }
        }
        
        int result = chooser.showOpenDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }
        
        File selectedFile = chooser.getSelectedFile();
        
        try {
            // Read circuit file content
            String content = new String(Files.readAllBytes(selectedFile.toPath()), 
                                       java.nio.charset.StandardCharsets.UTF_8);
            
            // Import circuit using controller
            importController.importCircuitWithPrompt(content);
            
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, 
                "Failed to read circuit file: " + ex.getMessage(), 
                "Import Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onExport() {
        if (canvas.getWidth() <= 0 || canvas.getHeight() <= 0) {
            JOptionPane.showMessageDialog(this, "Canvas has invalid size to export.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export Circuit Image");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG and JPEG images", "png", "jpg", "jpeg");
        chooser.setFileFilter(filter);
        int res = chooser.showSaveDialog(this);
        if (res != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        String path = file.getAbsolutePath();
        String format = "png";
        if (path.toLowerCase().endsWith(".jpg") || path.toLowerCase().endsWith(".jpeg")) {
            format = "jpg";
        } else if (path.toLowerCase().endsWith(".png")) {
            format = "png";
        } else {
            // default to png and append extension
            path = path + ".png";
            file = new File(path);
            format = "png";
        }

        // Create image and paint the canvas onto it
        BufferedImage img = new BufferedImage(canvas.getWidth(), canvas.getHeight(), BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g2 = img.createGraphics();
        // optional: white background for JPG
        if (format.equals("jpg")) {
            g2.setColor(java.awt.Color.WHITE);
            g2.fillRect(0, 0, img.getWidth(), img.getHeight());
        }
        canvas.paintAll(g2);
        g2.dispose();

        try {
            boolean ok = ImageIO.write(img, format, file);
            if (!ok) throw new IOException("No appropriate writer found for format: " + format);
            JOptionPane.showMessageDialog(this, "Exported image to: " + file.getAbsolutePath(), "Export Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to export image: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onAnalyze() {
        // Ask controller to produce a table-based analysis (JScrollPane with JTable)
        JScrollPane tableScroll = canvas.getController().analyzeCircuitTable();
        if (tableScroll == null) {
            JOptionPane.showMessageDialog(this, "No analysis available.", "Analyze", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, tableScroll, "Circuit Analysis (Truth Table & Gate Outputs)", JOptionPane.INFORMATION_MESSAGE);
    }
}