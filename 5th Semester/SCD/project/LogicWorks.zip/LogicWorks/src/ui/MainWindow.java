package ui;

import javax.swing.*;
import controllers.CreateProjectController;
import controllers.ProjectController;
import models.Projects;
import java.io.File;

public class MainWindow extends JFrame {
    private JButton btnCreate;
    private JButton btnLoad;
    private CreateProjectController createProjectController;
    private ProjectController projectController;

    public MainWindow() {
        btnCreate = new JButton("Create New Project");
        btnLoad = new JButton("Load Project");
        createProjectController = new CreateProjectController();
        projectController = new ProjectController();

        setLayout(new java.awt.FlowLayout());
        add(btnCreate);
        add(btnLoad);

        setTitle("LogicWorks Clone");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnCreate.addActionListener(e -> createProjectController.showUI());
        btnLoad.addActionListener(e -> onLoadProject());

        setVisible(true);
    }

    private void onLoadProject() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select project folder");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int res = chooser.showOpenDialog(this);
        if (res != JFileChooser.APPROVE_OPTION)
            return;
        File dir = chooser.getSelectedFile();
        try {
            Projects project = projectController.loadProject(dir.toPath());
            ProjectWindow pw = new ProjectWindow(project);
            pw.setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to load project: " + ex.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
