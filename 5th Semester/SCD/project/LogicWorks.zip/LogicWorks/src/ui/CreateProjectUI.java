package ui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import models.Projects;

public class CreateProjectUI extends JFrame {
    private Projects project;
    private JTextField projectNameField;
    private JTextField projectPathField;
    private JButton btnCreate;
    private JButton btnCancel;
    private JLabel nameLabel;
    private JLabel pathLabel;

    public CreateProjectUI() {
        projectNameField = new JTextField(20);
        projectPathField = new JTextField(20);
        btnCreate = new JButton("Create Project");
        btnCancel = new JButton("Cancel");
        nameLabel = new JLabel("Project Name:");
        pathLabel = new JLabel("Project Path:");
        setLayout(new java.awt.GridLayout(3, 2));
        add(nameLabel);
        add(projectNameField);
        add(pathLabel);
        add(projectPathField);
        add(btnCreate);
        add(btnCancel);
        setTitle("Create New Project");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public Projects getProject() {
        String name = projectNameField.getText();
        String path = projectPathField.getText();
        project = new Projects(name, path);
        return project;
    }

    public void addCreateListener(ActionListener l) {
        btnCreate.addActionListener(l);
    }

    public void addCancelListener(ActionListener l) {
        btnCancel.addActionListener(l);
    }

}
