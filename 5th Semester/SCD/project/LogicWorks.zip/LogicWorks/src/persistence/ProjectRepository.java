package persistence;

import models.Projects;
import models.Circuits;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;

public class ProjectRepository {

    // JSON metadata filename
    private static final String META_FILE = ".project_meta.json";

    /**
     * Load a Projects instance from the given directory. If metadata doesn't exist,
     * returns a Projects with name = directory name and path = parent path.
     */
    public Projects loadFromDirectory(Path dir) throws IOException {
        if (dir == null)
            return null;
        if (!Files.exists(dir) || !Files.isDirectory(dir)) {
            throw new IOException("Project directory does not exist: " + dir);
        }

        String projectName = dir.getFileName().toString();
        String projectPath = dir.getParent() != null ? dir.getParent().toString() : dir.toString();
        Projects project = new Projects(projectName, projectPath);

        Path meta = dir.resolve(META_FILE);
        if (!Files.exists(meta)) {
            return project;
        }

        String json = new String(Files.readAllBytes(meta), java.nio.charset.StandardCharsets.UTF_8);

        // Extract name and path
        String name = extractString(json, "name");
        String path = extractString(json, "path");
        if (name != null && !name.isEmpty())
            project.setProjectName(name);
        if (path != null && !path.isEmpty())
            project.setProjectPath(path);

        // Extract circuits array
        List<String> circuits = extractStringArray(json, "circuits");
        for (String c : circuits) {
            if (c != null && !c.trim().isEmpty())
                project.addCircuit(new Circuits(c));
        }

        return project;
    }

    //Save project metadata as JSON into the project directory.
    public void save(Projects project) throws IOException {
        if (project == null)
            throw new IllegalArgumentException("project is null");
        Path dir = Paths.get(project.getProjectPath(), project.getProjectName());
        if (!Files.exists(dir))
            Files.createDirectories(dir);

        Path meta = dir.resolve(META_FILE);

        StringBuilder sb = new StringBuilder();
        sb.append('{');
        sb.append("\n  \"name\": \"").append(escapeJson(project.getProjectName())).append('\"');
        sb.append(",\n  \"path\": \"").append(escapeJson(project.getProjectPath())).append('\"');
        sb.append(",\n  \"circuits\": [");
        List<Circuits> list = project.getCircuits();
        for (int i = 0; i < list.size(); i++) {
            sb.append('\n').append("    \"").append(escapeJson(list.get(i).getCircuitName())).append('\"');
            if (i < list.size() - 1)
                sb.append(',');
        }
        sb.append('\n').append("  ]\n}");

        Files.write(meta, sb.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    /**
     * Get the directory where individual circuit files are stored for a project.
     */
    public Path getCircuitsDir(Projects project) {
        return Paths.get(project.getProjectPath(), project.getProjectName(), "circuits");
    }

    public Path getCircuitFile(Projects project, Circuits circuit) {
        String filename = circuit.getCircuitName() + ".circ";
        return getCircuitsDir(project).resolve(filename);
    }

    /**
     * Read a circuit file; if it doesn't exist, create an empty file and return empty string.
     */
    public String readCircuit(Projects project, Circuits circuit) throws IOException {
        Path file = getCircuitFile(project, circuit);
        Path dir = file.getParent();
        if (!Files.exists(dir)) Files.createDirectories(dir);
        if (!Files.exists(file)) Files.write(file, new byte[0]);
        byte[] bytes = Files.readAllBytes(file);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    /**
     * Write circuit content to disk, creates parent dirs as needed.
     */
    public void writeCircuit(Projects project, Circuits circuit, String content) throws IOException {
        Path file = getCircuitFile(project, circuit);
        Path dir = file.getParent();
        if (!Files.exists(dir)) Files.createDirectories(dir);
        Files.write(file, content == null ? new byte[0] : content.getBytes(StandardCharsets.UTF_8));
    }

    // Helper to escape JSON string characters
    private String escapeJson(String s) {
        if (s == null)
            return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // Extract a JSON string value for a given key 
    private String extractString(String json, String key) {
        Pattern p = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"(.*?)\"", Pattern.DOTALL);
        Matcher m = p.matcher(json);
        if (m.find())
            return unescapeJson(m.group(1));
        return null;
    }

    // Extract a JSON array of strings for a given key
    private List<String> extractStringArray(String json, String key) {
        List<String> result = new ArrayList<>();
        Pattern p = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\\[(.*?)\\]", Pattern.DOTALL);
        Matcher m = p.matcher(json);
        if (m.find()) {
            String inside = m.group(1);
            Pattern s = Pattern.compile("\"(.*?)\"", Pattern.DOTALL);
            Matcher m2 = s.matcher(inside);
            while (m2.find()) {
                result.add(unescapeJson(m2.group(1)));
            }
        }
        return result;
    }

    private String unescapeJson(String s) {
        if (s == null)
            return null;
        return s.replace("\\\"", "\"").replace("\\n", "\n").replace("\\\\", "\\");
    }

    public void deleteCircuit(Projects project, Circuits circuit) throws IOException {
        try {
            Path file = getCircuitFile(project, circuit);
            if (Files.exists(file)) {
                Files.delete(file);
                //delete the circuits names from .project_meta.json
                project.getCircuits().removeIf(c -> c.getCircuitName().equals(circuit.getCircuitName()));
                save(project);
            }
        } catch (IOException e) {
            throw new IOException("Failed to delete circuit file: " + e.getMessage(), e);
        }
    }
}
