import ui.MainWindow;
public class app {
    public static void main(String[] args) {
        MainWindow mainWindow = new MainWindow();
        
        mainWindow.setVisible(true);
    }
}