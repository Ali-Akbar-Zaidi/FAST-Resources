package utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import models.Component;
import models.Connector;
import models.Port;
import models.InputSwitch;
import models.OutputLight;
import models.AndGate;
import models.OrGate;
import models.NotGate;
import controllers.CircuitCanvasController;
import java.util.ArrayList;

public class CircuitCanvas extends JPanel {
    private int rows;
    private int cols;
    private int cellSize;
    private ArrayList<Component> circuitComponents;
    private Component selectedComponent;
    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;
    private CircuitCanvasController controller;

    public CircuitCanvas(int rows, int cols, int cellSize) {
        this.rows = rows;
        this.cols = cols;
        this.cellSize = cellSize;
        this.circuitComponents = new ArrayList<>();
        this.selectedComponent = null;
        this.dragging = false;

        setPreferredSize(new Dimension(cols * cellSize, rows * cellSize));
        setBackground(Color.WHITE);

        this.controller = new CircuitCanvasController(this);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                controller.handleMousePressed(e.getX(), e.getY());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                controller.handleMouseReleased();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                controller.handleMouseDragged(e.getX(), e.getY());
            }
        });
    }

    public String serializeToString() {
        StringBuilder sb = new StringBuilder();
        // Components
        for (Component c : circuitComponents) {
            String type = "UNKNOWN";
            if (c instanceof AndGate) type = "AND";
            else if (c instanceof OrGate) type = "OR";
            else if (c instanceof NotGate) type = "NOT";
            else if (c instanceof InputSwitch) type = "INPUT";
            else if (c instanceof OutputLight) type = "OUTPUT";

            sb.append("COMPONENT|").append(type)
              .append("|").append(escape(c.getName()))
              .append("|").append(c.getPositionX())
              .append("|").append(c.getPositionY());

            if (c instanceof InputSwitch) {
                sb.append("|").append(((InputSwitch) c).getSwitchState() ? "1" : "0");
            }

            sb.append("\n");
        }

        // Connections
        if (controller != null && controller.getConnectionManager() != null) {
            for (Connector conn : controller.getConnectionManager().getConnectors()) {
                if (conn.getSource() != null && conn.getSink() != null && conn.getSinkPort() != null) {
                    sb.append("CONNECTION|")
                      .append(escape(conn.getSource().getName()))
                      .append("|")
                      .append(escape(conn.getSink().getName()))
                      .append("|")
                      .append(conn.getSinkPort().getPortIndex())
                      .append("\n");
                }
            }
        }

        return sb.toString();
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\|");
    }

    private String unescape(String s) {
        if (s == null) return "";
        return s.replace("\\|", "|").replace("\\\\", "\\");
    }

    public void loadFromSerializedString(String content) {
        // Clear existing
        if (controller != null && controller.getConnectionManager() != null) {
            controller.getConnectionManager().clear();
        }
        circuitComponents.clear();

        if (content == null || content.trim().isEmpty()) {
            repaint();
            return;
        }

        String[] lines = content.split("\\r?\\n");
        // First pass: create components
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("COMPONENT|")) {
                String[] parts = line.split("\\|", -1);
                // parts: COMPONENT, TYPE, NAME, X, Y, [STATE]
                if (parts.length < 5) continue;
                String type = parts[1];
                String name = unescape(parts[2]);
                int x = Integer.parseInt(parts[3]);
                int y = Integer.parseInt(parts[4]);
                Component c = null;
                switch (type.toUpperCase()) {
                    case "AND": c = new AndGate(name, x, y); break;
                    case "OR": c = new OrGate(name, x, y); break;
                    case "NOT": c = new NotGate(name, x, y); break;
                    case "INPUT": c = new InputSwitch(name, x, y); break;
                    case "OUTPUT": c = new OutputLight(name, x, y); break;
                    default: break;
                }
                if (c != null) {
                    // if input, restore state
                    if (c instanceof InputSwitch && parts.length >= 6) {
                        String st = parts[5];
                        ((InputSwitch) c).setSwitchState("1".equals(st));
                    }
                    circuitComponents.add(c);
                }
            }
        }

        // Second pass: create connections
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("CONNECTION|")) {
                String[] parts = line.split("\\|", -1);
                if (parts.length < 4) continue;
                String srcName = unescape(parts[1]);
                String dstName = unescape(parts[2]);
                int dstPort = 0;
                try { dstPort = Integer.parseInt(parts[3]); } catch (Exception e) { dstPort = 0; }

                Component src = findComponentByName(srcName);
                Component dst = findComponentByName(dstName);
                if (src == null || dst == null) continue;
                Port sourcePort = src.getOutputPort();
                if (dst.getInputPorts().size() <= dstPort) continue;
                Port sinkPort = dst.getInputPorts().get(dstPort);
                try {
                    if (controller != null && controller.getConnectionManager() != null) {
                        controller.getConnectionManager().createConnection(sourcePort, sinkPort);
                    }
                } catch (Exception ex) {
                    System.err.println("Failed to create connection: " + ex.getMessage());
                }
            }
        }

        if (controller != null && controller.getConnectionManager() != null) {
            controller.getConnectionManager().processAllConnections();
        }

        repaint();
    }

    private Component findComponentByName(String name) {
        for (Component c : circuitComponents) {
            if (c.getName().equalsIgnoreCase(name)) return c;
        }
        return null;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        drawGrid(g2d);
        drawConnections(g2d);
        drawComponents(g2d);
    }

    private void drawGrid(Graphics2D g) {
        g.setColor(new Color(220, 220, 220));
        g.setStroke(new BasicStroke(1));

        for (int i = 0; i <= rows; i++) {
            g.drawLine(0, i * cellSize, cols * cellSize, i * cellSize);
        }
        for (int j = 0; j <= cols; j++) {
            g.drawLine(j * cellSize, 0, j * cellSize, rows * cellSize);
        }
    }

    private void drawConnections(Graphics2D g) {
        if (controller != null && controller.getConnectionManager() != null) {
            for (Connector conn : controller.getConnectionManager().getConnectors()) {
                conn.draw(g);
            }
        }
    }

    private void drawComponents(Graphics2D g) {
        for (Component component : circuitComponents) {
            component.draw(g, component.getPositionX(), component.getPositionY());

            // Highlight selected component
            if (component == selectedComponent) {
                g.setColor(new Color(255, 200, 0, 100));
                g.setStroke(new BasicStroke(3));
                g.drawRect(component.getPositionX() - 5, component.getPositionY() - 5, 
                          Component.GATE_WIDTH + 10, Component.GATE_HEIGHT + 10);
            }
        }
    }

    // Getters and Setters
    public int getRows() {
        return rows;
    }


    
    public int getCols() {
        return cols;
    }

    public int getCellSize() {
        return cellSize;
    }

    public ArrayList<Component> getCircuitComponents() {
        return circuitComponents;
    }

    public Component getSelectedComponent() {
        return selectedComponent;
    }

    public void setSelectedComponent(Component component) {
        this.selectedComponent = component;
    }

    public boolean isDragging() {
        return dragging;
    }

    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }

    public int getDragOffsetX() {
        return dragOffsetX;
    }

    public void setDragOffsetX(int dragOffsetX) {
        this.dragOffsetX = dragOffsetX;
    }

    public int getDragOffsetY() {
        return dragOffsetY;
    }

    public void setDragOffsetY(int dragOffsetY) {
        this.dragOffsetY = dragOffsetY;
    }

    public CircuitCanvasController getController() {
        return controller;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Circuit Components:\n");
        for (Component component : circuitComponents) {
            sb.append(component.getName())
              .append(" at (")
              .append(component.getPositionX())
              .append(", ")
              .append(component.getPositionY())
              .append(")\n");
        }
        return sb.toString();
    }
}
