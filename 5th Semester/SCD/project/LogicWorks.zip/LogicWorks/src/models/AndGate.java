package models;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Font;

public class AndGate extends Component {
    public AndGate(String name, int positionX, int positionY) {
        super(name, positionX, positionY);
    }

    @Override
    protected void initializePorts() {
        inputPorts.add(new Port("IN1", Port.PortType.INPUT, this, 0));
        inputPorts.add(new Port("IN2", Port.PortType.INPUT, this, 1));
        outputPort = new Port("OUT", Port.PortType.OUTPUT, this, 0);
    }

    @Override
    public void setInput(boolean... inputs) {
        this.inputValues = inputs;
    }

    @Override
    public void execute() {
        if (inputValues == null || inputValues.length == 0) {
            outputValue = false;
            return;
        }
        outputValue = true;
        for (boolean input : inputValues) {
            outputValue &= input;
        }
    }

    @Override
    public boolean getOutput() {
        return outputValue;
    }
    
    @Override
    public void draw(Graphics2D g, int x, int y) {
        g.setColor(DEFAULT_COLOR);
        int rectWidth = GATE_WIDTH / 2;
        int semiwidth = GATE_WIDTH / 6;
        g.fillRect(x, y, rectWidth + 1, GATE_HEIGHT);
        g.fillArc(x + semiwidth, y, GATE_HEIGHT, GATE_HEIGHT, -90, 180);
        
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2));
        g.drawLine(x, y, x, y + GATE_HEIGHT);
        g.drawLine(x, y, x + rectWidth, y);
        g.drawLine(x, y + GATE_HEIGHT, x + rectWidth, y + GATE_HEIGHT);
        g.drawArc(x + semiwidth, y, GATE_HEIGHT, GATE_HEIGHT, -90, 180);
        
        // Draw extended input wires with color based on value
        boolean input1 = (inputValues != null && inputValues.length > 0) ? inputValues[0] : false;
        boolean input2 = (inputValues != null && inputValues.length > 1) ? inputValues[1] : false;
        
        // Input 1 wire
        g.setColor(input1 ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x - 20, y + 10, x, y + 10);
        
        // Input 2 wire
        g.setColor(input2 ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.drawLine(x - 20, y + 30, x, y + 30);
        
        // Draw input port indicators
        g.setColor(Color.RED);
        g.fillOval(x - 20 - PORT_RADIUS, y + 10 - PORT_RADIUS, PORT_RADIUS * 2, PORT_RADIUS * 2);
        g.fillOval(x - 20 - PORT_RADIUS, y + 30 - PORT_RADIUS, PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw output wire
        g.setColor(outputValue ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x + rectWidth + GATE_HEIGHT/2, y + GATE_HEIGHT/2, 
                   x + rectWidth + GATE_HEIGHT/2 + 10, y + GATE_HEIGHT/2);
        
        // Draw output port indicator
        g.setColor(Color.GREEN);
        g.fillOval(x + rectWidth + GATE_HEIGHT/2 + 10 - PORT_RADIUS, 
                   y + GATE_HEIGHT/2 - PORT_RADIUS, PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw component name
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        g.drawString(name, x, y - 5);
    }
}