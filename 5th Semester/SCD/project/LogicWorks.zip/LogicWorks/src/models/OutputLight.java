package models;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Font;

public class OutputLight extends Component {
    
    public OutputLight(String name, int positionX, int positionY) {
        super(name, positionX, positionY);
        this.outputValue = false;
    }

    @Override
    protected void initializePorts() {
        // Only input port
        inputPorts.add(new Port("IN", Port.PortType.INPUT, this, 0));
    }

    @Override
    public void setInput(boolean... inputs) {
        if (inputs.length > 0) {
            this.inputValues = inputs;
        }
    }

    @Override
    public void execute() {
        if (inputValues != null && inputValues.length > 0) {
            this.outputValue = inputValues[0];
        } else {
            this.outputValue = false;
        }
    }

    @Override
    public boolean getOutput() {
        return outputValue;
    }
    
    @Override
    public void draw(Graphics2D g, int x, int y) {
        // Draw input port with extended wire
        g.setColor(Color.RED);
        g.fillOval(x - 10 - PORT_RADIUS, y + GATE_HEIGHT/2 - PORT_RADIUS, 
                   PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw connection line
        g.setColor(outputValue ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x - 10, y + GATE_HEIGHT/2, x, y + GATE_HEIGHT/2);
        
        // Draw light bulb
        if (outputValue) {
            g.setColor(new Color(255, 255, 100)); // Bright yellow when ON
        } else {
            g.setColor(new Color(150, 150, 150)); // Gray when OFF
        }
        g.fillOval(x + 5, y + 5, 30, 30);
        
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2));
        g.drawOval(x + 5, y + 5, 30, 30);
        
        // Draw light rays when ON
        if (outputValue) {
            g.setColor(new Color(255, 255, 0, 100));
            for (int i = 0; i < 8; i++) {
                double angle = i * Math.PI / 4;
                int x1 = x + 20 + (int)(20 * Math.cos(angle));
                int y1 = y + 20 + (int)(20 * Math.sin(angle));
                int x2 = x + 20 + (int)(28 * Math.cos(angle));
                int y2 = y + 20 + (int)(28 * Math.sin(angle));
                g.setStroke(new BasicStroke(3));
                g.drawLine(x1, y1, x2, y2);
            }
        }
        
        // Draw component name above
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        g.drawString(name, x, y - 5);
    }
}