package models;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;

public class Connector {
    protected String name;
    protected Color color;
    protected Component source;
    protected Component sink;
    protected Port sourcePort;
    protected Port sinkPort;
    protected boolean value;

    public Connector(String name, Component source, Component sink, Port sourcePort, Port sinkPort) {
        this.name = name;
        this.source = source;
        this.sink = sink;
        this.sourcePort = sourcePort;
        this.sinkPort = sinkPort;
        this.color = Color.BLACK;
        this.value = false;
    }

    public void process() {
        if (source != null) {
            this.value = source.getOutput();
        }
    }

    public void draw(Graphics2D g) {
        if (sourcePort == null || sinkPort == null) {
            return;
        }
        
        int startX = sourcePort.getAbsoluteX();
        int startY = sourcePort.getAbsoluteY();
        int endX = sinkPort.getAbsoluteX();
        int endY = sinkPort.getAbsoluteY();
        
        // Set color based on signal value
        if (value) {
            g.setColor(new Color(0, 200, 0)); // Green for true
        } else {
            g.setColor(new Color(100, 100, 100)); // Gray for false
        }
        
        g.setStroke(new BasicStroke(3));
        
        // Draw line from source to sink
        g.drawLine(startX, startY, endX, endY);
        
        // Draw small circles at endpoints
        g.fillOval(startX - 4, startY - 4, 12, 12);
        g.fillOval(endX - 4, endY - 4, 12, 12);
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Component getSource() {
        return source;
    }

    public void setSource(Component source) {
        this.source = source;
    }

    public Component getSink() {
        return sink;
    }

    public void setSink(Component sink) {
        this.sink = sink;
    }

    public Port getSourcePort() {
        return sourcePort;
    }

    public Port getSinkPort() {
        return sinkPort;
    }

    public boolean getValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return name + ": " + source.getName() + " -> " + sink.getName();
    }
}