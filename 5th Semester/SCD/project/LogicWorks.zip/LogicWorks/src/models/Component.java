package models;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public abstract class Component {
    // Abstract class representing a generic component
    protected String name;
    protected int positionX;
    protected int positionY;

    // runtime values
    protected boolean[] inputValues;
    protected boolean outputValue;

    // Ports for connections
    protected List<Port> inputPorts;
    protected Port outputPort;

    // Connected components
    protected List<Connector> inputConnections;
    protected List<Connector> outputConnections;

    // design variables
    public static final int GATE_WIDTH = 60;
    public static final int GATE_HEIGHT = 40;
    public static final int PORT_RADIUS = 5;

    public static final Color DEFAULT_COLOR = new Color(100, 150, 200);

    public Component(String name, int positionX, int positionY) {
        this.name = name;
        this.positionX = positionX;
        this.positionY = positionY;
        this.inputConnections = new ArrayList<>();
        this.outputConnections = new ArrayList<>();
        this.inputPorts = new ArrayList<>();
        initializePorts();
    }

    // Initialize ports based on component type
    protected abstract void initializePorts();

    public String getName() {
        return name;
    }

    public int getPositionX() {
        return positionX;
    }

    public int getPositionY() {
        return positionY;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPositionX(int positionX) {
        this.positionX = positionX;
    }

    public void setPositionY(int positionY) {
        this.positionY = positionY;
    }

    // Set input values for the component
    public abstract void setInput(boolean... inputs);

    // Execute component logic
    public abstract void execute();

    // Get last computed output
    public abstract boolean getOutput();

    // Draw method
    public abstract void draw(java.awt.Graphics2D g, int x, int y);

    // Connection management
    public void addInputConnection(Connector connector) {
        inputConnections.add(connector);
    }

    public void addOutputConnection(Connector connector) {
        outputConnections.add(connector);
    }

    public void removeInputConnection(Connector connector) {
        inputConnections.remove(connector);
    }

    public void removeOutputConnection(Connector connector) {
        outputConnections.remove(connector);
    }

    public List<Connector> getInputConnections() {
        return inputConnections;
    }

    public List<Connector> getOutputConnections() {
        return outputConnections;
    }

    public List<Port> getInputPorts() {
        return inputPorts;
    }

    public Port getOutputPort() {
        return outputPort;
    }

    // Update inputs from connected components
    public void updateInputsFromConnections() {
        if (inputConnections.isEmpty()) {
            return;
        }

        boolean[] newInputs = new boolean[inputConnections.size()];
        for (int i = 0; i < inputConnections.size(); i++) {
            Connector conn = inputConnections.get(i);
            conn.process();
            newInputs[i] = conn.getValue();
        }
        setInput(newInputs);
    }
    // Factory method to create components
    public static Component create(String type, String name, int x, int y) {
        if (type == null)
            return null;
        switch (type.toUpperCase()) {
            case "AND":
                return new AndGate(name, x, y);
            case "OR":
                return new OrGate(name, x, y);
            case "NOT":
                return new NotGate(name, x, y);
            default:
                return null;
        }
    }
}
