package models;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Font;

public class NotGate extends Component {
    public NotGate(String name, int positionX, int positionY) {
        super(name, positionX, positionY);
    }

    @Override
    protected void initializePorts() {
        inputPorts.add(new Port("IN", Port.PortType.INPUT, this, 0));
        outputPort = new Port("OUT", Port.PortType.OUTPUT, this, 0);
    }

    @Override
    public void setInput(boolean... inputs) {
        if (inputs.length != 1) {
            throw new IllegalArgumentException("NOT gate requires exactly one input.");
        }
        this.inputValues = inputs;
    }

    @Override
    public void execute() {
        if (inputValues == null || inputValues.length == 0) {
            outputValue = false;
            return;
        }
        outputValue = !inputValues[0];
    }

    @Override
    public boolean getOutput() {
        return outputValue;
    }
    
    @Override
    public void draw(Graphics2D g, int x, int y) {
        g.setColor(DEFAULT_COLOR);
        
        int[] xPoints = {x, x + 50, x};
        int[] yPoints = {y, y + GATE_HEIGHT/2, y + GATE_HEIGHT};
        g.fillPolygon(xPoints, yPoints, 3);
        
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2));
        g.drawPolygon(xPoints, yPoints, 3);
        
        int bubbleX = x + 50;
        int bubbleY = y + GATE_HEIGHT/2 - 5;
        g.setColor(Color.WHITE);
        g.fillOval(bubbleX, bubbleY, 10, 10);
        g.setColor(Color.BLACK);
        g.drawOval(bubbleX, bubbleY, 10, 10);
        
        // Draw extended input wire with color
        boolean input = (inputValues != null && inputValues.length > 0) ? inputValues[0] : false;
        g.setColor(input ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x - 20, y + GATE_HEIGHT/2, x, y + GATE_HEIGHT/2);
        
        // Draw input port indicator
        g.setColor(Color.RED);
        g.fillOval(x - 20 - PORT_RADIUS, y + GATE_HEIGHT/2 - PORT_RADIUS, 
                   PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw output wire
        g.setColor(outputValue ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x + 60, y + GATE_HEIGHT/2, x + 60 + 10, y + GATE_HEIGHT/2);
        
        // Draw output port indicator
        g.setColor(Color.GREEN);
        g.fillOval(x + 60 + 10 - PORT_RADIUS, y + GATE_HEIGHT/2 - PORT_RADIUS, 
                   PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw component name
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        g.drawString(name, x, y - 5);
    }
}