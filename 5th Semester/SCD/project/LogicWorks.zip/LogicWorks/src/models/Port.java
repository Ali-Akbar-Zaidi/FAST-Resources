package models;

public class Port {
    public enum PortType {
        INPUT, OUTPUT
    }

    private String name;
    private PortType type;
    private Component parentComponent;
    private int portIndex;
    private boolean value;

    public Port(String name, PortType type, Component parentComponent, int portIndex) {
        this.name = name;
        this.type = type;
        this.parentComponent = parentComponent;
        this.portIndex = portIndex;
        this.value = false;
    }

    public int getAbsoluteX() {
        if (type == PortType.OUTPUT) {
            if (parentComponent instanceof NotGate) {
                return parentComponent.getPositionX() + 65; // NOT gate bubble end
            } else if (parentComponent instanceof AndGate) {
                return parentComponent.getPositionX() + Component.GATE_WIDTH + 5;
            } else if (parentComponent instanceof OrGate) {
                return parentComponent.getPositionX() + 60;
            }
            return parentComponent.getPositionX() + Component.GATE_WIDTH;
        } else {
            // Input port is on the left side
            return parentComponent.getPositionX() - 10;
        }
    }

    public int getAbsoluteY() {
        int baseY = parentComponent.getPositionY();
        if (type == PortType.OUTPUT) {
            return baseY + Component.GATE_HEIGHT / 2;
        } else {
            // Multiple input ports distributed vertically
            if (parentComponent instanceof NotGate) {
                // NOT gate has only one input
                return baseY + Component.GATE_HEIGHT / 2;
            } else {
                // AND and OR gates have two inputs
                if (portIndex == 0) {
                    return baseY + 10;
                } else {
                    return baseY + 30;
                }
            }
        }
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PortType getType() {
        return type;
    }

    public void setType(PortType type) {
        this.type = type;
    }

    public Component getParentComponent() {
        return parentComponent;
    }

    public void setParentComponent(Component parentComponent) {
        this.parentComponent = parentComponent;
    }

    public int getPortIndex() {
        return portIndex;
    }

    public void setPortIndex(int portIndex) {
        this.portIndex = portIndex;
    }

    public boolean getValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }
}