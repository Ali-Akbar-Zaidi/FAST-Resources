package models;

public class Circuits {
    private String circuitName;

    public Circuits() {
    }

    public Circuits(String circuitName) {
        this.circuitName = circuitName;
    }

    public String getCircuitName() {
        return circuitName;
    }

    public void setCircuitName(String circuitName) {
        this.circuitName = circuitName;
    }

    @Override
    public String toString() {
        return circuitName;
    }
}
