package models;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.geom.GeneralPath;
import java.awt.Font;

public class OrGate extends Component {
    public OrGate(String name, int positionX, int positionY) {
        super(name, positionX, positionY);
    }

    @Override
    protected void initializePorts() {
        inputPorts.add(new Port("IN1", Port.PortType.INPUT, this, 0));
        inputPorts.add(new Port("IN2", Port.PortType.INPUT, this, 1));
        outputPort = new Port("OUT", Port.PortType.OUTPUT, this, 0);
    }

    @Override
    public void setInput(boolean... inputs) {
        this.inputValues = inputs;
    }

    @Override
    public boolean getOutput() {
        return outputValue;
    }
    
    @Override
    public void execute() {
        if (inputValues == null || inputValues.length == 0) {
            outputValue = false;
            return;
        }
        outputValue = false;
        for (boolean input : inputValues) {
            outputValue |= input;
        }
    }

    @Override
    public void draw(Graphics2D g, int x, int y) {
        g.setColor(DEFAULT_COLOR);
        
        GeneralPath orPath = new GeneralPath();
        orPath.moveTo(x + 10, y);
        orPath.curveTo(x + 40, y, x + 50, y + 10, x + 55, y + GATE_HEIGHT/2);
        orPath.curveTo(x + 50, y + 30, x + 40, y + GATE_HEIGHT, x + 10, y + GATE_HEIGHT);
        orPath.quadTo(x + 5, y + GATE_HEIGHT/2, x + 10, y);
        orPath.closePath();
        g.fill(orPath);
    
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2));
        g.draw(orPath);
        
        GeneralPath backCurve = new GeneralPath();
        backCurve.moveTo(x + 10, y);
        backCurve.quadTo(x, y + GATE_HEIGHT/2, x + 10, y + GATE_HEIGHT);
        g.draw(backCurve);
        
        // Draw extended input wires with color
        boolean input1 = (inputValues != null && inputValues.length > 0) ? inputValues[0] : false;
        boolean input2 = (inputValues != null && inputValues.length > 1) ? inputValues[1] : false;
        
        // Input 1 wire
        g.setColor(input1 ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x - 15, y + 10, x + 8, y + 10);
        
        // Input 2 wire
        g.setColor(input2 ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.drawLine(x - 15, y + 30, x + 8, y + 30);
        
        // Draw input port indicators
        g.setColor(Color.RED);
        g.fillOval(x - 15 - PORT_RADIUS, y + 10 - PORT_RADIUS, PORT_RADIUS * 2, PORT_RADIUS * 2);
        g.fillOval(x - 15 - PORT_RADIUS, y + 30 - PORT_RADIUS, PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw output wire
        g.setColor(outputValue ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x + 55, y + GATE_HEIGHT/2, x + 55 + 10, y + GATE_HEIGHT/2);
        
        // Draw output port indicator
        g.setColor(Color.GREEN);
        g.fillOval(x + 55 + 10 - PORT_RADIUS, y + GATE_HEIGHT/2 - PORT_RADIUS, 
                   PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw component name
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        g.drawString(name, x, y - 5);
    }
}