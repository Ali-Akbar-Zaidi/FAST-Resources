package models;

import java.util.ArrayList;
import java.util.List;

public class Projects {
    private String projectName;
    private String projectPath;
    private List<Circuits> circuits;

    public Projects(String projectName, String projectPath) {
        this.projectName = projectName;
        this.projectPath = projectPath;
        this.circuits = new ArrayList<>();
    }

    // function to get project name and path
    public String getProjectName() {
        return projectName;
    }

    public String getProjectPath() {
        return projectPath;
    }

    // function to set project name and path
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public void setProjectPath(String projectPath) {
        this.projectPath = projectPath;
    }

    // Circuits management
    public List<Circuits> getCircuits() {
        return circuits;
    }

    public void addCircuit(String circuitName) {
        if (circuitName == null)
            return;
        circuitName = circuitName.trim();
        if (circuitName.isEmpty())
            return;
        circuits.add(new Circuits(circuitName));
    }

    public void addCircuit(Circuits circuit) {
        if (circuit == null)
            return;
        circuits.add(circuit);
    }

}
