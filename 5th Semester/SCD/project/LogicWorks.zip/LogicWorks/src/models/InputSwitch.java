package models;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Font;

public class InputSwitch extends Component {
    private boolean switchState = false;
    
    public InputSwitch(String name, int positionX, int positionY) {
        super(name, positionX, positionY);
        this.outputValue = false;
    }

    @Override
    protected void initializePorts() {
        // Only output port
        outputPort = new Port("OUT", Port.PortType.OUTPUT, this, 0);
    }

    @Override
    public void setInput(boolean... inputs) {
        // Input switch doesn't take inputs
    }

    @Override
    public void execute() {
        this.outputValue = switchState;
    }

    @Override
    public boolean getOutput() {
        return outputValue;
    }
    
    public void toggle() {
        switchState = !switchState;
        execute();
    }
    
    public boolean getSwitchState() {
        return switchState;
    }
    
    public void setSwitchState(boolean state) {
        this.switchState = state;
        execute();
    }
    
    @Override
    public void draw(Graphics2D g, int x, int y) {
        // Draw switch body
        if (switchState) {
            g.setColor(new Color(100, 200, 100)); // Green when ON
        } else {
            g.setColor(new Color(200, 100, 100)); // Red when OFF
        }
        g.fillRoundRect(x, y, 50, GATE_HEIGHT, 10, 10);
        
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2));
        g.drawRoundRect(x, y, 50, GATE_HEIGHT, 10, 10);
        
        // Draw label
        g.setFont(new Font("Arial", Font.BOLD, 12));
        String label = switchState ? "ON" : "OFF";
        g.drawString(label, x + 12, y + 25);
        
        // Draw output port
        g.setColor(Color.GREEN);
        g.fillOval(x + 50 + 5 - PORT_RADIUS, y + GATE_HEIGHT/2 - PORT_RADIUS, 
                   PORT_RADIUS * 2, PORT_RADIUS * 2);
        
        // Draw connection line from switch to port
        g.setColor(switchState ? new Color(0, 200, 0) : new Color(100, 100, 100));
        g.setStroke(new BasicStroke(2));
        g.drawLine(x + 50, y + GATE_HEIGHT/2, x + 50 + 5, y + GATE_HEIGHT/2);
        
        // Draw component name above
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        g.drawString(name, x, y - 5);
    }
}