package controllers;

import ui.CreateProjectUI;
import ui.ProjectWindow;
import models.Projects;
import java.io.File;

public class CreateProjectController {

    private CreateProjectUI view;

    public CreateProjectController() {
        this.view = new CreateProjectUI();

        // attach create listener
        this.view.addCreateListener(e -> {
            Projects p = view.getProject();
            if (p.getProjectName() == null || p.getProjectName().trim().isEmpty() ||
                    p.getProjectPath() == null || p.getProjectPath().trim().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(view, "Please provide project name and path.");
                return;
            }

            File dir = new File(p.getProjectPath(), p.getProjectName());
            if (!dir.exists()) {
                boolean created = dir.mkdirs();
                if (!created) {
                    javax.swing.JOptionPane.showMessageDialog(view,
                            "Failed to create project directory: " + dir.getAbsolutePath());
                    return;
                }
            }

            ProjectWindow pw = new ProjectWindow(p);
            pw.setVisible(true);
            view.dispose();
        });

        // attach cancel listener
        this.view.addCancelListener(e -> view.dispose());
    }

    public void showUI() {
        view.setVisible(true);
    }

    public Projects getProject() {
        return view.getProject();
    }
}
