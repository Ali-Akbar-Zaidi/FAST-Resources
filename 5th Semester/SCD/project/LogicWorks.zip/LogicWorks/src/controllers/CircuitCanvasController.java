package controllers;

import utils.CircuitCanvas;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import models.*;
import services.ConnectionManager;
import services.CircuitSimulator;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CircuitCanvasController {

    private CircuitCanvas canvas;
    private ConnectionManager connectionManager;
    private CircuitSimulator simulator;
    

    public CircuitCanvasController(CircuitCanvas canvas) {
        this.canvas = canvas;
        this.connectionManager = new ConnectionManager();
        this.simulator = new CircuitSimulator(canvas.getCircuitComponents(), connectionManager);
    }

    public void handleMousePressed(int x, int y) {
        Component clickedComponent = findComponentAt(x, y);
        
        if (clickedComponent != null) {
            // Check if it's an input switch being clicked on the body (for toggle)
            if (clickedComponent instanceof InputSwitch) {
                InputSwitch inputSwitch = (InputSwitch) clickedComponent;
                // Only toggle if clicking on the switch body, not near edges for dragging
                int relativeX = x - clickedComponent.getPositionX();
                int relativeY = y - clickedComponent.getPositionY();
                
                // Check if clicking in the center area (for toggle)
                if (relativeX > 10 && relativeX < 40 && relativeY > 5 && relativeY < 35) {
                    inputSwitch.toggle();
                    System.out.println(inputSwitch.getName() + " toggled to: " + 
                                     (inputSwitch.getSwitchState() ? "ON" : "OFF"));
                    canvas.repaint();
                    return;
                }
            }
            
            // Regular component selection and drag
            selectComponentAt(x, y);
            Component selected = canvas.getSelectedComponent();
            if (selected != null) {
                canvas.setDragging(true);
                canvas.setDragOffsetX(x - selected.getPositionX());
                canvas.setDragOffsetY(y - selected.getPositionY());
            }
        } else {
            // Clicked on empty space
            canvas.setSelectedComponent(null);
            canvas.repaint();
        }
    }

    public void handleMouseReleased() {
        canvas.setDragging(false);
        Component selected = canvas.getSelectedComponent();

        if (selected != null) {
            snapToGrid(selected);
            connectionManager.updateAllConnections();
            canvas.repaint();
        }
    }

    public void handleMouseDragged(int x, int y) {
        if (canvas.isDragging() && canvas.getSelectedComponent() != null) {
            Component selected = canvas.getSelectedComponent();
            int newX = x - canvas.getDragOffsetX();
            int newY = y - canvas.getDragOffsetY();
            selected.setPositionX(newX);
            selected.setPositionY(newY);
            connectionManager.updateAllConnections();
            canvas.repaint();
        }
    }

    private Component findComponentAt(int x, int y) {
        ArrayList<Component> components = canvas.getCircuitComponents();
        
        for (int i = components.size() - 1; i >= 0; i--) {
            Component comp = components.get(i);
            int compX = comp.getPositionX();
            int compY = comp.getPositionY();

            int width = (comp instanceof InputSwitch || comp instanceof OutputLight) ? 50 : Component.GATE_WIDTH;
            
            if (x >= compX && x <= compX + width &&
                    y >= compY && y <= compY + Component.GATE_HEIGHT) {
                return comp;
            }
        }
        return null;
    }

    private void selectComponentAt(int x, int y) {
        canvas.setSelectedComponent(findComponentAt(x, y));
    }

    private void snapToGrid(Component component) {
        int cellSize = canvas.getCellSize();
        int x = component.getPositionX();
        int y = component.getPositionY();

        int snappedX = Math.round((float) x / cellSize) * cellSize;
        int snappedY = Math.round((float) y / cellSize) * cellSize;

        component.setPositionX(snappedX);
        component.setPositionY(snappedY);
        canvas.repaint();
    }

    public void addGate(String gateType) {
        ArrayList<Component> components = canvas.getCircuitComponents();

        int cellSize = canvas.getCellSize();
        int componentWidth = 3 * cellSize;
        int componentHeight = 2 * cellSize;

        int canvasWidth = canvas.getWidth();
        int componentsPerRow = Math.max(1, (canvasWidth - cellSize) / (componentWidth + cellSize));

        int index = components.size();
        int row = index / componentsPerRow;
        int col = index % componentsPerRow;

        int x = cellSize + col * (componentWidth + cellSize);
        int y = cellSize + row * (componentHeight + cellSize);

        Component component = null;
        String name = gateType + "_" + components.size();

        switch (gateType.toUpperCase()) {
            case "AND":
                component = new AndGate(name, x, y);
                break;
            case "OR":
                component = new OrGate(name, x, y);
                break;
            case "NOT":
                component = new NotGate(name, x, y);
                break;
            case "INPUT":
                component = new InputSwitch(name, x, y);
                break;
            case "OUTPUT":
                component = new OutputLight(name, x, y);
                break;
            default:
                System.err.println("Unknown component type: " + gateType);
                return;
        }

        components.add(component);
        canvas.repaint();
        System.out.println("Added " + gateType + " gate: " + name);
    }

    public void removeSelectedGate() {
        Component selected = canvas.getSelectedComponent();

        if (selected != null) {
            connectionManager.removeConnectionsForComponent(selected);
            canvas.getCircuitComponents().remove(selected);
            canvas.setSelectedComponent(null);
            canvas.repaint();
            System.out.println("Removed: " + selected.getName());
        } else {
            System.out.println(" No component selected. Click on a component to select it first.");
        }
    }

    public void clearCanvas() {
        connectionManager.clear();
        canvas.getCircuitComponents().clear();
        canvas.setSelectedComponent(null);
        canvas.repaint();
        System.out.println("Canvas cleared");
    }

    public void simulate() {
        simulator.simulate();
        canvas.repaint();
        System.out.println("Simulation executed");
    }

    public void resetSimulation() {
        // Reset all input switches to OFF
        for (Component comp : canvas.getCircuitComponents()) {
            if (comp instanceof InputSwitch) {
                ((InputSwitch) comp).setSwitchState(false);
            }
        }
        simulator.reset();
        canvas.repaint();
        System.out.println("Simulation reset");
    }

    public String analyzeCircuit() {
        ArrayList<Component> components = canvas.getCircuitComponents();

        // Collect input switches and output lights in a deterministic order
        ArrayList<InputSwitch> inputs = new ArrayList<>();
        ArrayList<OutputLight> outputs = new ArrayList<>();
        for (Component c : components) {
            if (c instanceof InputSwitch) inputs.add((InputSwitch) c);
            if (c instanceof OutputLight) outputs.add((OutputLight) c);
        }

        if (inputs.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No input switches found to analyze.", "Analyze", JOptionPane.WARNING_MESSAGE);
            return "";
        }
        if (outputs.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No output lights found to analyze.", "Analyze", JOptionPane.WARNING_MESSAGE);
            return "";
        }

        int n = inputs.size();
        if (n > 16) {
            int confirm = JOptionPane.showConfirmDialog(null,
                "Analysis with more than 16 inputs may be slow and produce a large table. Continue?",
                "Large Analysis", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) return "";
        }

        int rows = 1 << n;

        // Build header mapping variable names (A,B,C...) to input names
        StringBuilder header = new StringBuilder();
        String[] varNames = new String[n];
        for (int i = 0; i < n; i++) {
            char var = (char) ('A' + i);
            varNames[i] = String.valueOf(var);
            header.append(varNames[i]).append("=").append(inputs.get(i).getName());
            if (i < n - 1) header.append(", ");
        }
        header.append("\n");

        StringBuilder table = new StringBuilder();
        table.append("Truth Table:\n");
        // header row
        for (int i = 0; i < n; i++) {
            table.append(String.format("%4s", varNames[i]));
        }
        for (OutputLight o : outputs) {
            table.append(String.format(" %8s", o.getName()));
        }
        table.append("\n");

        // Prepare containers for boolean expressions (sum of products)
        ArrayList<ArrayList<Integer>> trueMinterms = new ArrayList<>();
        for (int o = 0; o < outputs.size(); o++) trueMinterms.add(new ArrayList<>());

        // Iterate through all combinations
        for (int mask = 0; mask < rows; mask++) {
            // Set inputs according to mask
            for (int i = 0; i < n; i++) {
                boolean val = ((mask >> (n - 1 - i)) & 1) == 1; // MSB = first input
                inputs.get(i).setSwitchState(val);
            }

            // Run simulation for this input vector
            simulator.simulate();

            // Read outputs
            StringBuilder rowStr = new StringBuilder();
            for (int i = 0; i < n; i++) {
                boolean val = inputs.get(i).getSwitchState();
                rowStr.append(String.format("%4s", val ? "1" : "0"));
            }
            for (int oi = 0; oi < outputs.size(); oi++) {
                OutputLight out = outputs.get(oi);
                boolean outVal = out.getOutput();
                rowStr.append(String.format(" %8s", outVal ? "1" : "0"));
                if (outVal) trueMinterms.get(oi).add(mask);
            }
            table.append(rowStr.toString()).append("\n");
        }

        // Build boolean expressions (SOP) for each output
        StringBuilder expressions = new StringBuilder();
        expressions.append("\nBoolean Expressions (Sum of Products):\n");
        for (int oi = 0; oi < outputs.size(); oi++) {
            OutputLight out = outputs.get(oi);
            ArrayList<Integer> mins = trueMinterms.get(oi);
            if (mins.isEmpty()) {
                expressions.append(out.getName()).append(" = 0\n");
                continue;
            }
            ArrayList<String> terms = new ArrayList<>();
            for (int m : mins) {
                StringBuilder term = new StringBuilder();
                term.append("(");
                for (int i = 0; i < n; i++) {
                    boolean bit = ((m >> (n - 1 - i)) & 1) == 1;
                    if (i > 0) term.append(" & ");
                    if (bit) term.append(varNames[i]); else term.append("~").append(varNames[i]);
                }
                term.append(")");
                terms.add(term.toString());
            }
            String expr = String.join(" | ", terms);
            expressions.append(out.getName()).append(" = ").append(expr).append("\n");
        }

        // Final report
        StringBuilder report = new StringBuilder();
        report.append("Circuit Analysis Report\n");
        report.append("Inputs: ").append(header.toString()).append("\n");
        report.append(table.toString());
        report.append(expressions.toString());

        // Reset inputs to OFF after analysis
        for (InputSwitch in : inputs) in.setSwitchState(false);
        simulator.reset();
        canvas.repaint();

        return report.toString();
    }

    /**
     * Build a JTable inside a JScrollPane showing the truth table.
     * Columns: each input switch (by name), then every component's output (by name).
     */
    public JScrollPane analyzeCircuitTable() {
        ArrayList<Component> components = canvas.getCircuitComponents();

        // Collect input switches in deterministic order and all components for outputs
        ArrayList<InputSwitch> inputs = new ArrayList<>();
        for (Component c : components) {
            if (c instanceof InputSwitch) inputs.add((InputSwitch) c);
        }

        if (inputs.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No input switches found to analyze.", "Analyze", JOptionPane.WARNING_MESSAGE);
            return new JScrollPane(new JTable());
        }

        int n = inputs.size();
        int rows = 1 << n;

        // Columns: input names first
        ArrayList<String> colNames = new ArrayList<>();
        for (InputSwitch in : inputs) colNames.add(in.getName());

        // Then every component output column (by name).
        // Exclude InputSwitch from these columns to avoid showing input columns twice.
        ArrayList<Component> outputComponents = new ArrayList<>();
        for (Component c : components) {
            if (c instanceof InputSwitch) continue; // skip inputs (already shown)
            outputComponents.add(c);
            colNames.add(c.getName());
        }

        DefaultTableModel model = new DefaultTableModel();
        for (String cn : colNames) model.addColumn(cn);

        // Iterate all combinations
        for (int mask = 0; mask < rows; mask++) {
            // Set inputs
            Object[] row = new Object[colNames.size()];
            for (int i = 0; i < n; i++) {
                boolean val = ((mask >> (n - 1 - i)) & 1) == 1;
                inputs.get(i).setSwitchState(val);
                row[i] = val ? 1 : 0;
            }

            // Simulate
            simulator.simulate();

            // Fill outputs for each component
            for (int j = 0; j < outputComponents.size(); j++) {
                Component comp = outputComponents.get(j);
                boolean outVal = comp.getOutput();
                row[n + j] = outVal ? 1 : 0;
            }

            model.addRow(row);
        }

        // Reset inputs
        for (InputSwitch in : inputs) in.setSwitchState(false);
        simulator.reset();

        JTable table = new JTable(model);
        table.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        // Allow columns to autosize based on header
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(100);
        }

        JScrollPane scroll = new JScrollPane(table);
        scroll.setPreferredSize(new java.awt.Dimension(Math.min(1200, colNames.size() * 100), 400));
        return scroll;
    }

    // New method to create connection by component name
    public void connectSelectedToComponent() {
        Component selected = canvas.getSelectedComponent();
        
        if (selected == null) {
            JOptionPane.showMessageDialog(null, 
                "Please select a component first!", 
                "No Component Selected", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Get the target component name from user
        String targetName = JOptionPane.showInputDialog(null,
            "Enter the name of the component to connect to:\n" +
            "(Current component: " + selected.getName() + ")",
            "Connect Component",
            JOptionPane.QUESTION_MESSAGE);
        
        if (targetName == null || targetName.trim().isEmpty()) {
            return; // User cancelled or entered nothing
        }

        // Find the target component
        Component targetComponent = findComponentByName(targetName.trim());
        
        if (targetComponent == null) {
            JOptionPane.showMessageDialog(null,
                "Component '" + targetName + "' not found!",
                "Component Not Found",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (targetComponent == selected) {
            JOptionPane.showMessageDialog(null,
                "Cannot connect a component to itself!",
                "Invalid Connection",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create connection based on component types
        try {
            createConnection(selected, targetComponent);
            canvas.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                "Connection failed: " + e.getMessage(),
                "Connection Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private Component findComponentByName(String name) {
        for (Component comp : canvas.getCircuitComponents()) {
            if (comp.getName().equalsIgnoreCase(name)) {
                return comp;
            }
        }
        return null;
    }

    private void createConnection(Component source, Component target) throws Exception {
        Port sourcePort = null;
        Port targetPort = null;

        // Determine source output port
        if (source.getOutputPort() != null) {
            sourcePort = source.getOutputPort();
        } else {
            throw new Exception(source.getName() + " has no output port!");
        }

        // Determine target input port
        if (target.getInputPorts().isEmpty()) {
            throw new Exception(target.getName() + " has no input ports!");
        }

        // For components with multiple input ports, find an available one
        for (Port port : target.getInputPorts()) {
            if (!connectionManager.isPortConnected(port)) {
                targetPort = port;
                break;
            }
        }

        if (targetPort == null) {
            throw new Exception("All input ports on " + target.getName() + " are already connected!");
        }

        // Create the connection
        connectionManager.createConnection(sourcePort, targetPort);
        System.out.println(" Connected " + source.getName() + " -> " + target.getName());
        
        JOptionPane.showMessageDialog(null,
            "Successfully connected:\n" + source.getName() + " -> " + target.getName(),
            "Connection Created",
            JOptionPane.INFORMATION_MESSAGE);
    }

    // Getters
    public ConnectionManager getConnectionManager() {
        return connectionManager;
    }

}
