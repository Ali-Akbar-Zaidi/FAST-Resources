package controllers;

import models.Component;
import models.Port;
import services.CircuitImportService;
import services.CircuitImportService.ConnectionData;
import services.CircuitImportService.ImportResult;
import services.ConnectionManager;
import utils.CircuitCanvas;

import javax.swing.*;
import java.util.List;

public class CircuitImportController {
    
    private CircuitCanvas canvas;
    private ConnectionManager connectionManager;
    private CircuitImportService importService;
    
    public CircuitImportController(CircuitCanvas canvas, ConnectionManager connectionManager) {
        this.canvas = canvas;
        this.connectionManager = connectionManager;
        this.importService = new CircuitImportService();
    }
    
    public boolean importCircuitWithPrompt(String circuitContent) {
        if (circuitContent == null || circuitContent.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "Circuit content is empty. Cannot import.",
                "Import Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Ask user for positioning offset
        String offsetInput = JOptionPane.showInputDialog(null,
            "Enter position offset for imported components:\n" +
            "Format: x,y (e.g., 200,100)\n" +
            "Leave empty for default (100,100)",
            "Import Position",
            JOptionPane.QUESTION_MESSAGE);
        
        int offsetX = 100;
        int offsetY = 100;
        
        if (offsetInput != null && !offsetInput.trim().isEmpty()) {
            try {
                String[] parts = offsetInput.split(",");
                if (parts.length == 2) {
                    offsetX = Integer.parseInt(parts[0].trim());
                    offsetY = Integer.parseInt(parts[1].trim());
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                    "Invalid offset format. Using default (100,100)",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
        
        return importCircuit(circuitContent, offsetX, offsetY);
    }
    
    public boolean importCircuit(String circuitContent, int offsetX, int offsetY) {
        // Call service layer to process import
        ImportResult result = importService.importCircuit(
            circuitContent,
            canvas.getCircuitComponents(),
            offsetX,
            offsetY
        );
        
        if (!result.isSuccess()) {
            JOptionPane.showMessageDialog(null,
                "Import failed: " + result.getErrorMessage(),
                "Import Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Add imported components to canvas
        List<Component> importedComponents = result.getImportedComponents();
        for (Component component : importedComponents) {
            canvas.getCircuitComponents().add(component);
        }
        
        // Create connections with error handling
        int successfulConnections = 0;
        int failedConnections = 0;
        StringBuilder errorLog = new StringBuilder();
        
        for (ConnectionData connData : result.getConnections()) {
            try {
                Component source = findComponentByName(connData.sourceName);
                Component target = findComponentByName(connData.sinkName);
                
                if (source == null || target == null) {
                    failedConnections++;
                    errorLog.append("- Connection skipped: ")
                            .append(connData.sourceName)
                            .append(" -> ")
                            .append(connData.sinkName)
                            .append(" (component not found)\n");
                    continue;
                }
                
                // Get source output port
                Port sourcePort = source.getOutputPort();
                if (sourcePort == null) {
                    failedConnections++;
                    errorLog.append("- Connection skipped: ")
                            .append(connData.sourceName)
                            .append(" has no output port\n");
                    continue;
                }
                
                // Get target input port
                if (target.getInputPorts().size() <= connData.sinkPortIndex) {
                    failedConnections++;
                    errorLog.append("- Connection skipped: ")
                            .append(connData.sinkName)
                            .append(" port ")
                            .append(connData.sinkPortIndex)
                            .append(" does not exist\n");
                    continue;
                }
                
                Port sinkPort = target.getInputPorts().get(connData.sinkPortIndex);
                
                // Check if port is already connected
                if (connectionManager.isPortConnected(sinkPort)) {
                    failedConnections++;
                    errorLog.append("- Connection skipped: ")
                            .append(connData.sinkName)
                            .append(" port ")
                            .append(connData.sinkPortIndex)
                            .append(" already connected\n");
                    continue;
                }
                
                // Create connection
                connectionManager.createConnection(sourcePort, sinkPort);
                successfulConnections++;
                
            } catch (Exception e) {
                failedConnections++;
                errorLog.append("- Connection failed: ")
                        .append(connData.sourceName)
                        .append(" -> ")
                        .append(connData.sinkName)
                        .append(" (")
                        .append(e.getMessage())
                        .append(")\n");
            }
        }
        
        // Process all connections
        connectionManager.processAllConnections();
        
        // Repaint canvas
        canvas.repaint();
        
        // Show summary dialog
        StringBuilder summary = new StringBuilder();
        summary.append("Import completed!\n\n");
        summary.append("Components imported: ").append(importedComponents.size()).append("\n");
        summary.append("Connections created: ").append(successfulConnections).append("\n");
        
        if (failedConnections > 0) {
            summary.append("Connections failed: ").append(failedConnections).append("\n\n");
            summary.append("Details:\n").append(errorLog.toString());
            
            JOptionPane.showMessageDialog(null,
                summary.toString(),
                "Import Completed with Warnings",
                JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                summary.toString(),
                "Import Successful",
                JOptionPane.INFORMATION_MESSAGE);
        }
        
        return true;
    }
    
    private Component findComponentByName(String name) {
        for (Component comp : canvas.getCircuitComponents()) {
            if (comp.getName().equalsIgnoreCase(name)) {
                return comp;
            }
        }
        return null;
    }
}