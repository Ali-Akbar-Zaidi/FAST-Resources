package controllers;

import models.Circuits;
import models.Projects;
import services.ProjectService;

import java.io.IOException;
import java.nio.file.Path;

public class ProjectController {

    private final ProjectService projectService = new ProjectService();

    public ProjectController() {
    }

    public Projects loadProject(Path dir) throws IOException {
        return projectService.loadFromDirectory(dir);
    }

    public void saveProject(Projects project) throws IOException {
        projectService.saveProject(project);
    }

    public String openCircuit(Projects project, Circuits circuit) throws IOException {
        return projectService.readCircuit(project, circuit);
    }

    public void saveCircuit(Projects project, Circuits circuit, String content) throws IOException {
        projectService.writeCircuit(project, circuit, content);
    }

    public void deleteCircuit(Projects project, Circuits circuit) throws IOException {
        projectService.deleteCircuit(project, circuit);
    }
}
