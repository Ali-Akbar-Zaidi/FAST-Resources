package controllers;

import models.Circuits;
import models.Projects;
import services.ProjectService;

import java.io.IOException;

public class CircuitController {

    private final ProjectService projectService = new ProjectService();

    public CircuitController() {
    }

    public Circuits createCircuit(Projects project, String name) {
        if (name == null)
            return null;
        name = name.trim();
        if (name.isEmpty())
            return null;
        Circuits c = new Circuits(name);
        project.addCircuit(c);
        return c;
    }

    public void saveProject(Projects project) throws IOException {
        projectService.saveProject(project);
    }

    public String openCircuit(Projects project, Circuits circuit) throws IOException {
        return projectService.readCircuit(project, circuit);
    }

    public void saveCircuit(Projects project, Circuits circuit, String content) throws IOException {
        projectService.writeCircuit(project, circuit, content);
    }

    public void deleteCircuit(Projects project, Circuits circuit) throws IOException {
        projectService.deleteCircuit(project, circuit);
    }
}
