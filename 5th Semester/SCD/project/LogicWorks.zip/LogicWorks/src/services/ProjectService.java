package services;

import models.Circuits;
import models.Projects;
import persistence.ProjectRepository;

import java.io.IOException;
import java.nio.file.Path;

public class ProjectService {

    private final ProjectRepository repo = new ProjectRepository();

    public Projects loadFromDirectory(Path dir) throws IOException {
        return repo.loadFromDirectory(dir);
    }

    public void saveProject(Projects project) throws IOException {
        repo.save(project);
    }

    public String readCircuit(Projects project, Circuits circuit) throws IOException {
        return repo.readCircuit(project, circuit);
    }

    public void writeCircuit(Projects project, Circuits circuit, String content) throws IOException {
        repo.writeCircuit(project, circuit, content);
    }

    public void deleteCircuit(Projects project, Circuits circuit) throws IOException {
        repo.deleteCircuit(project, circuit);
    }
}
