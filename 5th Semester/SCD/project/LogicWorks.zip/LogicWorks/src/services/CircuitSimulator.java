package services;

import models.Component;
import models.Connector;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CircuitSimulator {
    private List<Component> components;
    private ConnectionManager connectionManager;

    public CircuitSimulator(List<Component> components, ConnectionManager connectionManager) {
        this.components = components;
        this.connectionManager = connectionManager;
    }

    public void simulate() {
        // Topologically sort components and execute
        List<Component> sortedComponents = topologicalSort();
        
        for (Component component : sortedComponents) {
            // Update inputs from connections
            component.updateInputsFromConnections();
            // Execute logic
            component.execute();
        }
        
        // Process all connections to propagate values
        connectionManager.processAllConnections();
    }

    private List<Component> topologicalSort() {
        List<Component> sorted = new ArrayList<>();
        Set<Component> visited = new HashSet<>();
        Set<Component> visiting = new HashSet<>();

        for (Component component : components) {
            if (!visited.contains(component)) {
                topologicalSortUtil(component, visited, visiting, sorted);
            }
        }

        return sorted;
    }

    private void topologicalSortUtil(Component component, Set<Component> visited, 
                                      Set<Component> visiting, List<Component> sorted) {
        visiting.add(component);

        // Visit all components that this component depends on (inputs)
        for (Connector conn : component.getInputConnections()) {
            Component source = conn.getSource();
            if (!visited.contains(source)) {
                if (visiting.contains(source)) {
                    System.err.println("Warning: Cycle detected in circuit!");
                    continue;
                }
                topologicalSortUtil(source, visited, visiting, sorted);
            }
        }

        visiting.remove(component);
        visited.add(component);
        sorted.add(component);
    }

    public void reset() {
        for (Component component : components) {
            component.setInput(new boolean[]{false});
            component.execute();
        }
        connectionManager.processAllConnections();
    }
}
