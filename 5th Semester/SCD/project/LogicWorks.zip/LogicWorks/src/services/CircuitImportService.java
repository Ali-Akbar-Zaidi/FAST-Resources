package services;

import models.*;
import java.util.*;

public class CircuitImportService {

    public ImportResult importCircuit(String circuitContent,
            List<Component> targetComponents,
            int offsetX,
            int offsetY) {
        ImportResult result = new ImportResult();

        if (circuitContent == null || circuitContent.trim().isEmpty()) {
            result.setSuccess(false);
            result.setErrorMessage("Circuit content is empty");
            return result;
        }

        // Parse the circuit content
        ParsedCircuit parsed = parseCircuitContent(circuitContent);

        // Filter out INPUT and OUTPUT components
        List<ComponentData> filteredComponents = filterIOComponents(parsed.components);

        if (filteredComponents.isEmpty()) {
            result.setSuccess(false);
            result.setErrorMessage("No logic gates found to import (only INPUT/OUTPUT components)");
            return result;
        }

        // Check for name conflicts and generate unique names
        Map<String, String> nameMapping = generateUniqueNames(filteredComponents, targetComponents);

        // Create actual component instances with offset positions
        Map<String, Component> importedComponentMap = createComponents(
                filteredComponents, nameMapping, offsetX, offsetY);

        // Filter and remap connections (exclude connections to/from INPUT/OUTPUT)
        List<ConnectionData> filteredConnections = filterAndRemapConnections(
                parsed.connections, nameMapping, importedComponentMap);

        // Populate result
        result.setSuccess(true);
        result.setImportedComponents(new ArrayList<>(importedComponentMap.values()));
        result.setConnections(filteredConnections);
        result.setNameMapping(nameMapping);

        return result;
    }

    private ParsedCircuit parseCircuitContent(String content) {
        ParsedCircuit parsed = new ParsedCircuit();
        String[] lines = content.split("\\r?\\n");

        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty())
                continue;

            if (line.startsWith("COMPONENT|")) {
                ComponentData comp = parseComponentLine(line);
                if (comp != null) {
                    parsed.components.add(comp);
                }
            } else if (line.startsWith("CONNECTION|")) {
                ConnectionData conn = parseConnectionLine(line);
                if (conn != null) {
                    parsed.connections.add(conn);
                }
            }
        }

        return parsed;
    }

    private ComponentData parseComponentLine(String line) {
        String[] parts = line.split("\\|", -1);
        if (parts.length < 5)
            return null;

        ComponentData comp = new ComponentData();
        comp.type = parts[1];
        comp.name = unescape(parts[2]);
        comp.x = Integer.parseInt(parts[3]);
        comp.y = Integer.parseInt(parts[4]);

        // For INPUT switches, store state
        if (parts.length >= 6 && "INPUT".equalsIgnoreCase(comp.type)) {
            comp.state = "1".equals(parts[5]);
        }

        return comp;
    }

    private ConnectionData parseConnectionLine(String line) {
        String[] parts = line.split("\\|", -1);
        if (parts.length < 4)
            return null;

        ConnectionData conn = new ConnectionData();
        conn.sourceName = unescape(parts[1]);
        conn.sinkName = unescape(parts[2]);

        try {
            conn.sinkPortIndex = Integer.parseInt(parts[3]);
        } catch (Exception e) {
            conn.sinkPortIndex = 0;
        }

        return conn;
    }

    private List<ComponentData> filterIOComponents(List<ComponentData> components) {
        List<ComponentData> filtered = new ArrayList<>();

        for (ComponentData comp : components) {
            String type = comp.type.toUpperCase();
            if (!"INPUT".equals(type) && !"OUTPUT".equals(type)) {
                filtered.add(comp);
            }
        }

        return filtered;
    }

    private Map<String, String> generateUniqueNames(List<ComponentData> components,
            List<Component> existingComponents) {
        Map<String, String> nameMapping = new HashMap<>();
        Set<String> existingNames = new HashSet<>();

        // Collect existing names
        for (Component comp : existingComponents) {
            existingNames.add(comp.getName().toLowerCase());
        }

        // Generate unique names for each imported component
        for (ComponentData comp : components) {
            String originalName = comp.name;
            String newName = originalName;
            int counter = 1;

            // If name conflicts, append counter
            while (existingNames.contains(newName.toLowerCase()) ||
                    nameMapping.containsValue(newName)) {
                newName = originalName + "_import_" + counter;
                counter++;
            }

            nameMapping.put(originalName, newName);
            existingNames.add(newName.toLowerCase());
        }

        return nameMapping;
    }

    private Map<String, Component> createComponents(List<ComponentData> components,
            Map<String, String> nameMapping,
            int offsetX,
            int offsetY) {
        Map<String, Component> componentMap = new HashMap<>();

        for (ComponentData data : components) {
            String newName = nameMapping.get(data.name);
            int x = data.x + offsetX;
            int y = data.y + offsetY;

            // use Component factory method on the model class (preserve original
            // mapping/logic)
            Component component = Component.create(data.type, newName, x, y);

            if (component != null) {
                componentMap.put(data.name, component);
            }
        }

        return componentMap;
    }

    private List<ConnectionData> filterAndRemapConnections(List<ConnectionData> connections,
            Map<String, String> nameMapping,
            Map<String, Component> componentMap) {
        List<ConnectionData> filtered = new ArrayList<>();

        for (ConnectionData conn : connections) {
            // Check if both source and sink are in the imported components (not
            // INPUT/OUTPUT)
            if (componentMap.containsKey(conn.sourceName) &&
                    componentMap.containsKey(conn.sinkName)) {

                // Create remapped connection
                ConnectionData remapped = new ConnectionData();
                remapped.sourceName = nameMapping.get(conn.sourceName);
                remapped.sinkName = nameMapping.get(conn.sinkName);
                remapped.sinkPortIndex = conn.sinkPortIndex;

                filtered.add(remapped);
            }
        }

        return filtered;
    }

    private String unescape(String s) {
        if (s == null)
            return "";
        return s.replace("\\|", "|").replace("\\\\", "\\");
    }

    private static class ParsedCircuit {
        List<ComponentData> components = new ArrayList<>();
        List<ConnectionData> connections = new ArrayList<>();
    }

    private static class ComponentData {
        String type;
        String name;
        int x;
        int y;
        boolean state;
    }

    public static class ConnectionData {
        public String sourceName;
        public String sinkName;
        public int sinkPortIndex;
    }

    public static class ImportResult {
        private boolean success;
        private String errorMessage;
        private List<Component> importedComponents;
        private List<ConnectionData> connections;
        private Map<String, String> nameMapping;

        public ImportResult() {
            this.importedComponents = new ArrayList<>();
            this.connections = new ArrayList<>();
            this.nameMapping = new HashMap<>();
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public List<Component> getImportedComponents() {
            return importedComponents;
        }

        public void setImportedComponents(List<Component> importedComponents) {
            this.importedComponents = importedComponents;
        }

        public List<ConnectionData> getConnections() {
            return connections;
        }

        public void setConnections(List<ConnectionData> connections) {
            this.connections = connections;
        }

        public Map<String, String> getNameMapping() {
            return nameMapping;
        }

        public void setNameMapping(Map<String, String> nameMapping) {
            this.nameMapping = nameMapping;
        }
    }
}