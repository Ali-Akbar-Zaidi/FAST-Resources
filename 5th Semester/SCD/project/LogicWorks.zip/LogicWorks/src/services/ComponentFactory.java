package services;

import models.*;

public final class ComponentFactory {

    private ComponentFactory() {
        // utility
    }
    public static Component create(String type, String name, int x, int y) {
        if (type == null)
            return null;
        switch (type.toUpperCase()) {
            case "AND":
                return new AndGate(name, x, y);
            case "OR":
                return new OrGate(name, x, y);
            case "NOT":
                return new NotGate(name, x, y);
            default:
                return null;
        }
    }
}
