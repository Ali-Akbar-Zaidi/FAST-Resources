package services;

import models.Component;
import models.Connector;
import models.Port;
import java.util.ArrayList;
import java.util.List;

public class ConnectionManager {
    private List<Connector> connectors;
    private int connectorCounter;

    public ConnectionManager() {
        this.connectors = new ArrayList<>();
        this.connectorCounter = 0;
    }

    public Connector createConnection(Port sourcePort, Port sinkPort) {
        if (sourcePort == null || sinkPort == null) {
            throw new IllegalArgumentException("Source and sink ports cannot be null");
        }
        
        if (sourcePort.getType() != Port.PortType.OUTPUT) {
            throw new IllegalArgumentException("Source must be an OUTPUT port");
        }
        
        if (sinkPort.getType() != Port.PortType.INPUT) {
            throw new IllegalArgumentException("Sink must be an INPUT port");
        }
        
        // Check if sink port is already connected
        if (isPortConnected(sinkPort)) {
            throw new IllegalArgumentException("Input port already connected");
        }

        Component source = sourcePort.getParentComponent();
        Component sink = sinkPort.getParentComponent();
        
        String connectorName = "CONN_" + connectorCounter++;
        Connector connector = new Connector(connectorName, source, sink, sourcePort, sinkPort);
        
        // Add connector to both components
        source.addOutputConnection(connector);
        sink.addInputConnection(connector);
        
        // Add to global list
        connectors.add(connector);
        
        return connector;
    }

    public void removeConnection(Connector connector) {
        if (connector == null) {
            return;
        }

        // Remove from components
        Component source = connector.getSource();
        Component sink = connector.getSink();
        
        if (source != null) {
            source.removeOutputConnection(connector);
        }
        if (sink != null) {
            sink.removeInputConnection(connector);
        }

        // Remove from global list
        connectors.remove(connector);
    }

    public void removeConnectionsForComponent(Component component) {
        List<Connector> toRemove = new ArrayList<>();
        
        for (Connector conn : connectors) {
            if (conn.getSource() == component || conn.getSink() == component) {
                toRemove.add(conn);
            }
        }
        
        for (Connector conn : toRemove) {
            removeConnection(conn);
        }
    }

    public Port findPortAt(Component component, int x, int y) {
        if (component == null) {
            return null;
        }

        // Check output port
        Port outputPort = component.getOutputPort();
        if (outputPort != null && isPointNearPort(outputPort, x, y)) {
            return outputPort;
        }

        // Check input ports
        for (Port inputPort : component.getInputPorts()) {
            if (isPointNearPort(inputPort, x, y)) {
                return inputPort;
            }
        }

        return null;
    }

    private boolean isPointNearPort(Port port, int x, int y) {
        int portX = port.getAbsoluteX();
        int portY = port.getAbsoluteY();
        int threshold = 10; // pixels

        int dx = x - portX;
        int dy = y - portY;
        return (dx * dx + dy * dy) <= (threshold * threshold);
    }

    // New method to check if a port is already connected
    public boolean isPortConnected(Port port) {
        if (port == null) {
            return false;
        }
        
        for (Connector conn : connectors) {
            if (port.getType() == Port.PortType.INPUT) {
                if (conn.getSinkPort() == port) {
                    return true;
                }
            } else if (port.getType() == Port.PortType.OUTPUT) {
                if (conn.getSourcePort() == port) {
                    return true;
                }
            }
        }
        return false;
    }

    public List<Connector> getConnectors() {
        return connectors;
    }

    public void updateAllConnections() {
    }

    public void processAllConnections() {
        for (Connector conn : connectors) {
            conn.process();
        }
    }

    public void clear() {
        // Properly remove all connections
        List<Connector> toRemove = new ArrayList<>(connectors);
        for (Connector conn : toRemove) {
            removeConnection(conn);
        }
        connectorCounter = 0;
    }
}
