Action()
{

	lr_think_time(38);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=15:oC5RaA5csyP0L2khE2e1WWp8uvne76L9li5ZVfPYx_4&cup2hreq=d9deb43df220ebe90cc2cfdc853de56d4c10afa04ee30b094648dfde6003be0a", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,download,puff,run,xz,zucc\",\"apps\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{cc040acf-253c-4e14-baee-6d1991ea4e3f}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"CHBF\",\""
		"cached_items\":[{\"sha256\":\"40bcac8ec67b813b5a01fc4f2a820ff6f3311bb2c44b8bcd11e905f4a453ca19\"}],\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{c0cdaabe-ffca-4d12-8fa6-379fa2c9b4e4}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"20251020.824019708.14\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\""
		"a02aa0594f76065c1ccb48221548b6ade3b6be5b50d24f226579e5d67d5e971d\"}],\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{3c75e47a-df7e-49b1-8201-3ae8606c8ed1}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"9.62.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"38c89b12bb20a8f2751c9c7cd2e31c173a47af08c115e1ecccc2f5151a2cf2c6\"}],\"cohort\":\"1:1uh3:\",\""
		"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{fb0265cf-d6a3-4a65-9717-e4d403813798}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.7.18.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"03c55f4f45c2a62c467f5bcf7e3fbee31e9ec27abeccefed06adc927cdf52968\"}],\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{d49697ed-23c1-4bb9-b566-f324772ecd47}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"144.0.7512.1\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"caf22da361a099ee7f504cfd6018872cff61e16946d0a5a57fb07c529bfa8072\"}],\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{8ad414f8-4b83-4fec-bd27-8c33ad105e2e}\",\"rd\":6893},\"updatecheck"
		"\":{},\"version\":\"2025.9.29.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CHBF\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{7a85ef67-6e4a-4513-940b-927c0d230133}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"2be74d0afadd4c9b2ee33695e1f81fc5ce5dc3016cd8a13cfa0e1f0b571834ea\"}],\""
		"cohort\":\"1::\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{97ad0f29-64de-4f77-ab40-d72b1aad6279}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"1.0.0.19\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"CHBF\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{32e544d7-1f5a-4ef3-8e9f-1062b9227c9f}\",\"rd\":6893},\"updatecheck\":{},\"version\":\""
		"1.0.7.1744928549\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"2952996ce90b46eba6d1f09a6a1b70f3125fab9500b413f9148cdfc2b3284fd9\"}],\"cohort\":\"1:287f:\",\"cohortname\":\"Auto full\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{52ba36d9-adbd-4575-9792-8088f286a3c1}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"10156\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"CHBF\",\""
		"cached_items\":[{\"sha256\":\"d258f4f112cbff3c06069680768196d70cb5115221c11399aad7c534cf3d3d01\"}],\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{492cb198-9fd0-4c57-a9b4-33ea2954d4ac}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"1492\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"a96d0537e5204a795c385b49eb255a32ea466726425aa5dc7fa873fea8acb579\"}"
		"],\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{347cb763-c7ba-43dc-8e97-604d25013f58}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"3087\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"d0312aac7d10581b8661788ca5c51cc2277bd73d62f37dc2dee3d02e562cd767\"}],\"cohort\":\"1:ut9/1a0f:\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":6790,\""
		"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{2a859c80-fb2d-4f9d-88d0-1f61380526b7}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.11.13.121\"},{\"appid\":\"pmagihnlncbcefglppponlgakiphldeh\",\"brand\":\"CHBF\",\"cohort\":\"1:2ntr:\",\"cohortname\":\"General Release\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{135967ee-627c-4d23-a192-930daabdd2d3}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2024.10.17.0\"},{\"appid\":\""
		"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"abd78817d137324a488d33f2be78c1bcce014f22371fa586085f59d53d0290e8\"}],\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{35fa7d31-d543-4bce-8e98-1f6f2c7783c0}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"572\"},{\"appid\":\"hajigopbbjhghbfimgkfmpenfkclmohk\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\""
		"abd93867c038d4d17c101ace2226d7e21303d984d7097271392bae6be478495b\"}],\"cohort\":\"1:2tdl:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{0bd2bbdc-87c9-47f5-b2a7-4b52a8ce4d79}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"4\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CHBF\",\"cohort\":\"1:2qw3:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\""
		"{1593fd07-352b-495c-895a-431f36792af6}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"4.10.2934.0\"},{\"appid\":\"mcfjlbnicoclaecapilmleaelokfnijm\",\"brand\":\"CHBF\",\"cohort\":\"1:2ql3:\",\"cohortname\":\"Initial upload\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{0dadf9ad-7acc-48f8-9afa-1c2157dbcad3}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2024.11.26.0\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"CHBF\",\"cached_items\":["
		"{\"sha256\":\"4a06cfbce6f26c81ec6cba52e84985c0111183e0b06a953b14992b4511bb78af\"}],\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{739942b5-7825-4ada-9b2f-7950cc6b4e91}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.10.7.1\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"CHBF\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{d6bbd997-26fa-4e7d-b29e-9906fa840db5}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"ldfkbgjbencjpgjfleiooeldhjdapggh\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"38582b0c9b1c6d2f052dc20f30201c30698f3c6a4f3da4567991bf5629b1fa94\"}],\"cohort\":\"1:2v8l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{4c212c5b-4fd9-4e5d-a366-6cb32f026630}\",\"rd\":6893},\"updatecheck\":{},\""
		"version\":\"2025.8.19.0\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"CHBF\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{45e9c1bf-f906-4f3e-baa6-00fabffdbbf7}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"CHBF\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{4943f669-8103-4e9b-8e06-bc6e9e653113}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"bjbcblmdcnggnibecjikpoljcgkbgphl\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"221e69c75d2ebd901f43b49f837382c045686b79ba68ba6ace4a7e0a20cd9177\"}],\"cohort\":\"1:2t4f:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6832,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{96010b61-186e-4ce7-aa26-46ac3279b3a4}\",\"rd\":6893},\""
		"updatecheck\":{},\"version\":\"20251114.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"4497d8060d0e53c12b4403aa9ebe7e827d4880bae3f4139a26a4feb7ed64c4a2\"}],\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{b507ee1c-0531-491b-80c3-81a13a868643}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.6.13.84507\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\","
		"\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"56c21927faa028be6ce18c931660eec37e41da4bfbfd47cafa48350f828c0dbd\"}],\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{8e2d8449-ea8b-4995-b6b3-21d020ebceb2}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.7.24.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":8,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\""
		":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.6060\"},\"prodversion\":\"142.0.7444.60\",\"protocol\":\"4.0\",\"requestid\":\"{c76aa2d0-f165-419b-bf36-8e088ca3f565}\",\"sessionid\":\"{51c7320f-5771-44c1-82a8-6a475bee2ed8}\",\"updaters\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"143.0.7482.0\"},\""
		"updaterversion\":\"142.0.7444.60\"}}", 
		LAST);

	lr_think_time(35);

	lr_start_transaction("1_SignIn");

	web_submit_data("Login", 
		"Action=https://flexstudent.nu.edu.pk/login/Login", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://flexstudent.nu.edu.pk/Login", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=23L-3065", ENDITEM, 
		"Name=password", "Value=QaimMehdi313", ENDITEM, 
		"Name=g-recaptcha-response", "Value="
		"0cAFcWeA5VZarcoVEiDQC2yUbTZKMHy2GH4Bm3Rc11G4MU56Y0bhNoDtHjL9efDt6HbMbACl1v3JnkRiQg5q8QJFbymt7ZsL7CVuyGA6ISAfz2jFAJGK9Fj-YxfH43zduJZh-HqHLtzEKcojRv8okTAcVL-OPpzXSyVs8BFdeJ8fhzoofuV88IqSfjrIcUOfBVMz-Zk_OALCeFTubEA1G0NpY7t6eSSVN8AMXU3xp6mnlwkXUcNUiRE1Ij0PeCj8hKPecLLoprIw3EZP0wz33LemJZTVsSPNnygQv--Pnol2qAE8-WCIUXIwzxnnYjzuydqhjlXERmMjYWde2_adz44rl1yY9O-nq8EkVPfRuTJY1lT9LQFdXgd1ZkoVYrbvIvbtrBvstjjux--1s_JrCqfyDV6rVM4QnW4ZLzAuPF8b9GUinSetz6vXSWyxHy6d2M6h17OM6Eq46dd7hXYP6q4_KGKivttRu7mmfaIt7c8l11moTTXaRo"
		"OHDD-aQkzXBzy0nscjL0fhOibVQEpndX-mBa7UYKq4zUH0Snm8Nf1R_wJZuKbOU5sutGrEAMQ-laYRPPNSkGcvp2maE9LMqtz__GVdxmEq1zgq9TwIWOaMnSMRNmMMSzv3JdtXZ9Q6uvPMp8et1C-9fUieSAi9v4-25UPTwWJ65NX-2wBCgDH_Us8_QBZrfbgZ54O7BjPDhv1i3O2nr9JYmUGjIboR3rk9Gfi__f07_M4J5eNZWman7MPChDI0ivQEXG4mScFJffUZswx1S1DwrU", ENDITEM, 
		LAST);

	web_url("flexstudent.nu.edu.pk_2", 
		"URL=https://flexstudent.nu.edu.pk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://flexstudent.nu.edu.pk/Login", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/Assets/vendors/base/fonts/flaticon/Flaticon.woff", "Referer=https://flexstudent.nu.edu.pk/Assets/vendors/base/vendors.bundle.css", ENDITEM, 
		"Url=https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700%7CRoboto:300,400,500,600,700", ENDITEM, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINMTQyLjAuNzQ0NC42MBopCAUQARobCg0IBRAGGAEiAzAwMTABEMTRHRoCGARbu-XEIgQgASACKAEaKAgQEAEaGgoNCBAQBhgBIgMwMDEwARDIOBoCGASsbJ_UIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARC0-BIaAhgEM-IWuCIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQ1_ASGgIYBHxxqzQiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEIz4BxoCGAQRJl3KIgQgASACKAEaKQgHEAEaGwoNCAcQBhgBIgMwMDEwARCsiBMaAhgENDZjoSIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQuD4aAhgEV_XkQyIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQqLQHGgIYBAHJgqYiBCABIAIoARonCA"
		"kQARoZCg0ICRAGGAEiAzAwMTABECMaAhgE5WKYUCIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ7xoaAhgE_jp2CCIEIAEgAigBGikIDRABGhsKDQgNEAYYASIDMDAxMAEQ5NkCGgIYBIUrYhUiBCABIAIoASICCAM=&$ct=application/x-protobuf&key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("1_SignIn",LR_AUTO);

	return 0;
}