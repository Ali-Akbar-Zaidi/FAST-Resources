# 1 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c"
# 1 "F:\\LoadRunner\\VuGen\\include/lrun.h" 1
 
 












 











# 103 "F:\\LoadRunner\\VuGen\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "F:\\LoadRunner\\VuGen\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);
char *   lr_encrypt_ex (const char *plaintext);
char *   lr_decrypt_ex (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 515 "F:\\LoadRunner\\VuGen\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 518 "F:\\LoadRunner\\VuGen\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 542 "F:\\LoadRunner\\VuGen\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 576 "F:\\LoadRunner\\VuGen\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 599 "F:\\LoadRunner\\VuGen\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 623 "F:\\LoadRunner\\VuGen\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 702 "F:\\LoadRunner\\VuGen\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 763 "F:\\LoadRunner\\VuGen\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 778 "F:\\LoadRunner\\VuGen\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 802 "F:\\LoadRunner\\VuGen\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 814 "F:\\LoadRunner\\VuGen\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 822 "F:\\LoadRunner\\VuGen\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 828 "F:\\LoadRunner\\VuGen\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 933 "F:\\LoadRunner\\VuGen\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 940 "F:\\LoadRunner\\VuGen\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 962 "F:\\LoadRunner\\VuGen\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1038 "F:\\LoadRunner\\VuGen\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1067 "F:\\LoadRunner\\VuGen\\include/lrun.h"


# 1079 "F:\\LoadRunner\\VuGen\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 







int   lr_cyberark_get_vault(char * first_param, ...);
int   lr_cyberark_get_vault_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 







int   lr_aws_get_secret(char * first_param, ...);
int   lr_aws_get_secret_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 







int   lr_azure_set_service_port(int portNum);
int   lr_azure_ad_client_get_token(char * first_param, ...);
int   lr_azure_ad_client_get_token_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_azure_kv_get_secret(char * first_param, ...);
int   lr_azure_kv_get_secret_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 







int   lr_hashicorp_vault_get_secret_with_token(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_token_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_get_secret_with_approle_auth(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_approle_auth_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_get_secret_with_jwt_auth(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_jwt_auth_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_get_secret_with_userpass_auth(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_userpass_auth_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_save_secret_from_json(char * first_param, ...);
int   lr_hashicorp_vault_save_secret_from_json_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_search_row(PVCI pvci, char * columnNames, char * messages, char * delimiter, char * **outcolumns, char * **outvalues);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_search_row(char * columnNames, char * messages, char * delimiter);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 

















# 1 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c" 2

# 1 "F:\\LoadRunner\\VuGen\\include/SharedParameter.h" 1



 
 
 
 
# 100 "F:\\LoadRunner\\VuGen\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_search_row(PVCI2 pvci, char *columnNames, char *messages, char *delimiter, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_search_row(char *columnNames, char *messages, char *delimiter);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c" 2

# 1 "globals.h" 1



 
 

# 1 "F:\\LoadRunner\\VuGen\\include/web_api.h" 1







# 1 "F:\\LoadRunner\\VuGen\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "F:\\LoadRunner\\VuGen\\include/as_web.h"


# 802 "F:\\LoadRunner\\VuGen\\include/as_web.h"



























# 840 "F:\\LoadRunner\\VuGen\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "F:\\LoadRunner\\VuGen\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "F:\\LoadRunner\\VuGen\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);

  int					 
web_util_set_request_header(
	  const char *		aRequestHeaderNameStr,
	  const char *		aRequestHeaderValueStr);

 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "lrw_custom_body.h" 1
 




# 8 "globals.h" 2


 
 


# 3 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c" 2

# 1 "vuser_init.c" 1
 







vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("folae", 
		"URL=https://www.google.com/async/folae?async=_fmt:pb", 
		"Resource=1", 
		"RecContentType=application/x-protobuffer", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"LAST");

	web_custom_request("v1:GetModels", 
		"URL=https://optimizationguide-pa.googleapis.com/v1:GetModels?key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\n\n\\x08\\x02\\x10\\xC6\\xB2\\xE1\\xA0\\x06 \\x15\nt\\x08\t\\x10\\x8B\\xB8\\x9D\\xC0\\x06 \\x152h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8E\\x01\n\n\\x08\r\\x10\\xF1\\xE9\\x9C\\x9E\\x06 \\x15\ng\\x08\\x0F\\x10\\x05 \\x152_\nWtype.googleapis.com/google.internal.chrome.optimizationguide.v1.PageTopicsModelMetadata\\x12\\x04\\x08\\x020\\x02\ng\\x08\\x10 \\x152a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\nt\\x08\\x14\\x10\\xEB\\xAC\\x9D\\xC0\\x06 \\x152h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8E\\x01\ng\\x08\\x15 \\x152a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08\\x17 \\x152a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\n\\x08\\x18\\x10\\xF4\\xC3\\x90\\xB8\\x06 \\x15\n\n\\x08\\x19\\x10\\xE4\\xB7\\x83\\xC8\\x06 \\x15\nr\\x08\\x1A\\x10\\xA6\\x80\\xEC\\xA8\\x06 \\x152f\n`type.googleapis.com/google.internal.chrome.optimizationguide.v1.AutocompleteScoringModelMetadata\\x12\\x02\\x10\\x02\ng\\x08\\x1B \\x152a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\t\\x08\\x1E\\x10\\xC7\\xE8\\x81i \\x15\nn\\x08-\\x10\\x9B\\xE2\\xC0\\xE5\\x80\\x07 \\x152a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08. \\x152a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\\x18\\x06*\\x05en-US2\\x02\\x08\\x06", 
		"LAST");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=142", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("flexstudent.nu.edu.pk", 
		"URL=https://flexstudent.nu.edu.pk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=/assets/app/media/img//bg/bg-5.jpg", "Referer=https://flexstudent.nu.edu.pk/Login", "ENDITEM", 
		"Url=https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700%7CRoboto:300,400,500,600,700", "Referer=https://flexstudent.nu.edu.pk/", "ENDITEM", 
		"Url=/Assets/vendors/base/fonts/line-awesome/line-awesome.woff2?v=1.1.", "Referer=https://flexstudent.nu.edu.pk/Assets/vendors/base/vendors.bundle.css", "ENDITEM", 
		"Url=https://www.gstatic.com/recaptcha/releases/TkacYOdEJbdB_JjX802TMer9/recaptcha__en.js", "Referer=https://flexstudent.nu.edu.pk/", "ENDITEM", 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvMTQyLjAuNzQ0NC42MBIgCXIRl943RrkGEgUN541ADhIFDc5BTHohLU9gdq2lLLMSGQkDyP9aAQkFChIFDXhvEhkhbNwpvyCreYEYt6nKAQ==?alt=proto", "Referer=", "ENDITEM", 
		"Url=https://www.gstatic.com/recaptcha/releases/TkacYOdEJbdB_JjX802TMer9/styles__ltr.css", "Referer=https://www.google.com/", "ENDITEM", 
		"LAST");

	return 0;
}
# 4 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c" 2

# 1 "Action.c" 1
Action()
{

	lr_think_time(38);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=15:oC5RaA5csyP0L2khE2e1WWp8uvne76L9li5ZVfPYx_4&cup2hreq=d9deb43df220ebe90cc2cfdc853de56d4c10afa04ee30b094648dfde6003be0a", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,download,puff,run,xz,zucc\",\"apps\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{cc040acf-253c-4e14-baee-6d1991ea4e3f}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"CHBF\",\""
		"cached_items\":[{\"sha256\":\"40bcac8ec67b813b5a01fc4f2a820ff6f3311bb2c44b8bcd11e905f4a453ca19\"}],\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{c0cdaabe-ffca-4d12-8fa6-379fa2c9b4e4}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"20251020.824019708.14\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\""
		"a02aa0594f76065c1ccb48221548b6ade3b6be5b50d24f226579e5d67d5e971d\"}],\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{3c75e47a-df7e-49b1-8201-3ae8606c8ed1}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"9.62.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"38c89b12bb20a8f2751c9c7cd2e31c173a47af08c115e1ecccc2f5151a2cf2c6\"}],\"cohort\":\"1:1uh3:\",\""
		"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{fb0265cf-d6a3-4a65-9717-e4d403813798}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.7.18.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"03c55f4f45c2a62c467f5bcf7e3fbee31e9ec27abeccefed06adc927cdf52968\"}],\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{d49697ed-23c1-4bb9-b566-f324772ecd47}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"144.0.7512.1\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"caf22da361a099ee7f504cfd6018872cff61e16946d0a5a57fb07c529bfa8072\"}],\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{8ad414f8-4b83-4fec-bd27-8c33ad105e2e}\",\"rd\":6893},\"updatecheck"
		"\":{},\"version\":\"2025.9.29.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CHBF\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{7a85ef67-6e4a-4513-940b-927c0d230133}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"2be74d0afadd4c9b2ee33695e1f81fc5ce5dc3016cd8a13cfa0e1f0b571834ea\"}],\""
		"cohort\":\"1::\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{97ad0f29-64de-4f77-ab40-d72b1aad6279}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"1.0.0.19\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"CHBF\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{32e544d7-1f5a-4ef3-8e9f-1062b9227c9f}\",\"rd\":6893},\"updatecheck\":{},\"version\":\""
		"1.0.7.1744928549\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"2952996ce90b46eba6d1f09a6a1b70f3125fab9500b413f9148cdfc2b3284fd9\"}],\"cohort\":\"1:287f:\",\"cohortname\":\"Auto full\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{52ba36d9-adbd-4575-9792-8088f286a3c1}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"10156\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"CHBF\",\""
		"cached_items\":[{\"sha256\":\"d258f4f112cbff3c06069680768196d70cb5115221c11399aad7c534cf3d3d01\"}],\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{492cb198-9fd0-4c57-a9b4-33ea2954d4ac}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"1492\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"a96d0537e5204a795c385b49eb255a32ea466726425aa5dc7fa873fea8acb579\"}"
		"],\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{347cb763-c7ba-43dc-8e97-604d25013f58}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"3087\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"d0312aac7d10581b8661788ca5c51cc2277bd73d62f37dc2dee3d02e562cd767\"}],\"cohort\":\"1:ut9/1a0f:\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":6790,\""
		"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{2a859c80-fb2d-4f9d-88d0-1f61380526b7}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.11.13.121\"},{\"appid\":\"pmagihnlncbcefglppponlgakiphldeh\",\"brand\":\"CHBF\",\"cohort\":\"1:2ntr:\",\"cohortname\":\"General Release\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{135967ee-627c-4d23-a192-930daabdd2d3}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2024.10.17.0\"},{\"appid\":\""
		"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"abd78817d137324a488d33f2be78c1bcce014f22371fa586085f59d53d0290e8\"}],\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{35fa7d31-d543-4bce-8e98-1f6f2c7783c0}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"572\"},{\"appid\":\"hajigopbbjhghbfimgkfmpenfkclmohk\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\""
		"abd93867c038d4d17c101ace2226d7e21303d984d7097271392bae6be478495b\"}],\"cohort\":\"1:2tdl:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{0bd2bbdc-87c9-47f5-b2a7-4b52a8ce4d79}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"4\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CHBF\",\"cohort\":\"1:2qw3:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\""
		"{1593fd07-352b-495c-895a-431f36792af6}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"4.10.2934.0\"},{\"appid\":\"mcfjlbnicoclaecapilmleaelokfnijm\",\"brand\":\"CHBF\",\"cohort\":\"1:2ql3:\",\"cohortname\":\"Initial upload\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{0dadf9ad-7acc-48f8-9afa-1c2157dbcad3}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2024.11.26.0\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"CHBF\",\"cached_items\":["
		"{\"sha256\":\"4a06cfbce6f26c81ec6cba52e84985c0111183e0b06a953b14992b4511bb78af\"}],\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{739942b5-7825-4ada-9b2f-7950cc6b4e91}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.10.7.1\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"CHBF\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{d6bbd997-26fa-4e7d-b29e-9906fa840db5}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"ldfkbgjbencjpgjfleiooeldhjdapggh\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"38582b0c9b1c6d2f052dc20f30201c30698f3c6a4f3da4567991bf5629b1fa94\"}],\"cohort\":\"1:2v8l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{4c212c5b-4fd9-4e5d-a366-6cb32f026630}\",\"rd\":6893},\"updatecheck\":{},\""
		"version\":\"2025.8.19.0\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"CHBF\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{45e9c1bf-f906-4f3e-baa6-00fabffdbbf7}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"CHBF\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{4943f669-8103-4e9b-8e06-bc6e9e653113}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"bjbcblmdcnggnibecjikpoljcgkbgphl\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"221e69c75d2ebd901f43b49f837382c045686b79ba68ba6ace4a7e0a20cd9177\"}],\"cohort\":\"1:2t4f:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6832,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{96010b61-186e-4ce7-aa26-46ac3279b3a4}\",\"rd\":6893},\""
		"updatecheck\":{},\"version\":\"20251114.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"4497d8060d0e53c12b4403aa9ebe7e827d4880bae3f4139a26a4feb7ed64c4a2\"}],\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{b507ee1c-0531-491b-80c3-81a13a868643}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.6.13.84507\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\","
		"\"brand\":\"CHBF\",\"cached_items\":[{\"sha256\":\"56c21927faa028be6ce18c931660eec37e41da4bfbfd47cafa48350f828c0dbd\"}],\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6790,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{8e2d8449-ea8b-4995-b6b3-21d020ebceb2}\",\"rd\":6893},\"updatecheck\":{},\"version\":\"2025.7.24.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":8,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\""
		":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.6060\"},\"prodversion\":\"142.0.7444.60\",\"protocol\":\"4.0\",\"requestid\":\"{c76aa2d0-f165-419b-bf36-8e088ca3f565}\",\"sessionid\":\"{51c7320f-5771-44c1-82a8-6a475bee2ed8}\",\"updaters\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"143.0.7482.0\"},\""
		"updaterversion\":\"142.0.7444.60\"}}", 
		"LAST");

	lr_think_time(35);

	lr_start_transaction("1_SignIn");

	web_submit_data("Login", 
		"Action=https://flexstudent.nu.edu.pk/login/Login", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://flexstudent.nu.edu.pk/Login", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=username", "Value=23L-3065", "ENDITEM", 
		"Name=password", "Value=QaimMehdi313", "ENDITEM", 
		"Name=g-recaptcha-response", "Value="
		"0cAFcWeA5VZarcoVEiDQC2yUbTZKMHy2GH4Bm3Rc11G4MU56Y0bhNoDtHjL9efDt6HbMbACl1v3JnkRiQg5q8QJFbymt7ZsL7CVuyGA6ISAfz2jFAJGK9Fj-YxfH43zduJZh-HqHLtzEKcojRv8okTAcVL-OPpzXSyVs8BFdeJ8fhzoofuV88IqSfjrIcUOfBVMz-Zk_OALCeFTubEA1G0NpY7t6eSSVN8AMXU3xp6mnlwkXUcNUiRE1Ij0PeCj8hKPecLLoprIw3EZP0wz33LemJZTVsSPNnygQv--Pnol2qAE8-WCIUXIwzxnnYjzuydqhjlXERmMjYWde2_adz44rl1yY9O-nq8EkVPfRuTJY1lT9LQFdXgd1ZkoVYrbvIvbtrBvstjjux--1s_JrCqfyDV6rVM4QnW4ZLzAuPF8b9GUinSetz6vXSWyxHy6d2M6h17OM6Eq46dd7hXYP6q4_KGKivttRu7mmfaIt7c8l11moTTXaRo"
		"OHDD-aQkzXBzy0nscjL0fhOibVQEpndX-mBa7UYKq4zUH0Snm8Nf1R_wJZuKbOU5sutGrEAMQ-laYRPPNSkGcvp2maE9LMqtz__GVdxmEq1zgq9TwIWOaMnSMRNmMMSzv3JdtXZ9Q6uvPMp8et1C-9fUieSAi9v4-25UPTwWJ65NX-2wBCgDH_Us8_QBZrfbgZ54O7BjPDhv1i3O2nr9JYmUGjIboR3rk9Gfi__f07_M4J5eNZWman7MPChDI0ivQEXG4mScFJffUZswx1S1DwrU", "ENDITEM", 
		"LAST");

	web_url("flexstudent.nu.edu.pk_2", 
		"URL=https://flexstudent.nu.edu.pk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://flexstudent.nu.edu.pk/Login", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=/Assets/vendors/base/fonts/flaticon/Flaticon.woff", "Referer=https://flexstudent.nu.edu.pk/Assets/vendors/base/vendors.bundle.css", "ENDITEM", 
		"Url=https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700%7CRoboto:300,400,500,600,700", "ENDITEM", 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINMTQyLjAuNzQ0NC42MBopCAUQARobCg0IBRAGGAEiAzAwMTABEMTRHRoCGARbu-XEIgQgASACKAEaKAgQEAEaGgoNCBAQBhgBIgMwMDEwARDIOBoCGASsbJ_UIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARC0-BIaAhgEM-IWuCIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQ1_ASGgIYBHxxqzQiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEIz4BxoCGAQRJl3KIgQgASACKAEaKQgHEAEaGwoNCAcQBhgBIgMwMDEwARCsiBMaAhgENDZjoSIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQuD4aAhgEV_XkQyIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQqLQHGgIYBAHJgqYiBCABIAIoARonCA"
		"kQARoZCg0ICRAGGAEiAzAwMTABECMaAhgE5WKYUCIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ7xoaAhgE_jp2CCIEIAEgAigBGikIDRABGhsKDQgNEAYYASIDMDAxMAEQ5NkCGgIYBIUrYhUiBCABIAIoASICCAM=&$ct=application/x-protobuf&key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", "Referer=", "ENDITEM", 
		"LAST");

	lr_end_transaction("1_SignIn",2);

	return 0;
}
# 5 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 6 "c:\\users\\syeda jabeen ali\\onedrive\\documents\\vugen\\scripts\\flexsignup\\\\combined_FlexSignUp.c" 2

