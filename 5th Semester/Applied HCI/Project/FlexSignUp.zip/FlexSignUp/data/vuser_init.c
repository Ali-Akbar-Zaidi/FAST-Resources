/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("folae", 
		"URL=https://www.google.com/async/folae?async=_fmt:pb", 
		"Resource=1", 
		"RecContentType=application/x-protobuffer", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_custom_request("v1:GetModels", 
		"URL=https://optimizationguide-pa.googleapis.com/v1:GetModels?key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\n\n\\x08\\x02\\x10\\xC6\\xB2\\xE1\\xA0\\x06 \\x15\nt\\x08\t\\x10\\x8B\\xB8\\x9D\\xC0\\x06 \\x152h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8E\\x01\n\n\\x08\r\\x10\\xF1\\xE9\\x9C\\x9E\\x06 \\x15\ng\\x08\\x0F\\x10\\x05 \\x152_\nWtype.googleapis.com/google.internal.chrome.optimizationguide.v1.PageTopicsModelMetadata\\x12\\x04\\x08\\x020\\x02\ng\\x08\\x10 \\x152a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\nt\\x08\\x14\\x10\\xEB\\xAC\\x9D\\xC0\\x06 \\x152h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8E\\x01\ng\\x08\\x15 \\x152a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08\\x17 \\x152a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\n\\x08\\x18\\x10\\xF4\\xC3\\x90\\xB8\\x06 \\x15\n\n\\x08\\x19\\x10\\xE4\\xB7\\x83\\xC8\\x06 \\x15\nr\\x08\\x1A\\x10\\xA6\\x80\\xEC\\xA8\\x06 \\x152f\n`type.googleapis.com/google.internal.chrome.optimizationguide.v1.AutocompleteScoringModelMetadata\\x12\\x02\\x10\\x02\ng\\x08\\x1B \\x152a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\t\\x08\\x1E\\x10\\xC7\\xE8\\x81i \\x15\nn\\x08-\\x10\\x9B\\xE2\\xC0\\xE5\\x80\\x07 \\x152a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08. \\x152a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\\x18\\x06*\\x05en-US2\\x02\\x08\\x06", 
		LAST);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=142", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("flexstudent.nu.edu.pk", 
		"URL=https://flexstudent.nu.edu.pk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/app/media/img//bg/bg-5.jpg", "Referer=https://flexstudent.nu.edu.pk/Login", ENDITEM, 
		"Url=https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700%7CRoboto:300,400,500,600,700", "Referer=https://flexstudent.nu.edu.pk/", ENDITEM, 
		"Url=/Assets/vendors/base/fonts/line-awesome/line-awesome.woff2?v=1.1.", "Referer=https://flexstudent.nu.edu.pk/Assets/vendors/base/vendors.bundle.css", ENDITEM, 
		"Url=https://www.gstatic.com/recaptcha/releases/TkacYOdEJbdB_JjX802TMer9/recaptcha__en.js", "Referer=https://flexstudent.nu.edu.pk/", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvMTQyLjAuNzQ0NC42MBIgCXIRl943RrkGEgUN541ADhIFDc5BTHohLU9gdq2lLLMSGQkDyP9aAQkFChIFDXhvEhkhbNwpvyCreYEYt6nKAQ==?alt=proto", "Referer=", ENDITEM, 
		"Url=https://www.gstatic.com/recaptcha/releases/TkacYOdEJbdB_JjX802TMer9/styles__ltr.css", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	return 0;
}
